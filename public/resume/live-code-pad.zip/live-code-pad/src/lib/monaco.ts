import type { LanguageOption, SupportedLanguage } from "@/types/editor";

export const LANGUAGES: LanguageOption[] = [
  { id: "javascript", label: "JavaScript", monacoLanguage: "javascript" },
  { id: "typescript", label: "TypeScript", monacoLanguage: "typescript" },
];

export const DEFAULT_LANGUAGE: SupportedLanguage = "javascript";

export const DEFAULT_CODE: Record<SupportedLanguage, string> = {
  javascript: `// Welcome to CodePad!\n// Start typing or invite someone to collaborate.\n\nfunction greet(name) {\n  return \`Hello, \${name}!\`;\n}\n\nconsole.log(greet("World"));\n`,
  typescript: `// Welcome to CodePad!\n\ninterface Person {\n  name: string;\n  age: number;\n}\n\nfunction greet(person: Person): string {\n  return \`Hello, \${person.name}!\`;\n}\n`,
};

export function getLanguageById(id: SupportedLanguage): LanguageOption {
  return LANGUAGES.find((l) => l.id === id) ?? LANGUAGES[0];
}
