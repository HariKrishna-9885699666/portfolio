import { describe, it, expect } from "vitest";
import {
  generateRoomId,
  generateSessionRoomId,
  generateUserName,
  generateUserColor,
  generateUserId,
} from "@/lib/room";

describe("generateRoomId", () => {
  it("should generate a 9-character string", () => {
    const id = generateRoomId();
    expect(id).toHaveLength(9);
  });

  it("should generate alphanumeric strings", () => {
    const id = generateRoomId();
    expect(id).toMatch(/^[a-zA-Z0-9_-]+$/);
  });

  it("should generate unique IDs", () => {
    const ids = new Set(Array.from({ length: 100 }, () => generateRoomId()));
    expect(ids.size).toBe(100);
  });
});

describe("generateSessionRoomId", () => {
  it("should include the slugified candidate name", () => {
    const id = generateSessionRoomId("Hari Krishna");
    expect(id).toMatch(/^hari-krishna-live-code-test-/);
  });

  it("should convert to lowercase", () => {
    const id = generateSessionRoomId("John DOE");
    expect(id).toMatch(/^john-doe-live-code-test-/);
  });

  it("should replace spaces with hyphens", () => {
    const id = generateSessionRoomId("Alice   Smith");
    expect(id).toMatch(/^alice-smith-live-code-test-/);
  });

  it("should remove special characters", () => {
    const id = generateSessionRoomId("Bob@#!O'Reilly");
    expect(id).toMatch(/^boboreilly-live-code-test-/);
  });

  it("should append a unique identifier", () => {
    const id = generateSessionRoomId("Test");
    // Format: "test-live-code-test-XXXXXX" where X is alphanumeric
    expect(id).toMatch(/^test-live-code-test-[a-zA-Z0-9]{6}$/);
  });

  it("should generate unique IDs for same name", () => {
    const ids = new Set(
      Array.from({ length: 50 }, () => generateSessionRoomId("Hari Krishna"))
    );
    expect(ids.size).toBe(50);
  });

  it("should handle empty name by using 'candidate' fallback", () => {
    const id = generateSessionRoomId("   '!@#  ");
    expect(id).toMatch(/^candidate-live-code-test-/);
  });

  it("should trim leading/trailing hyphens from slug", () => {
    const id = generateSessionRoomId("-Hari-");
    expect(id).toMatch(/^hari-live-code-test-/);
  });
});

describe("generateUserId", () => {
  it("should generate an ID starting with user-", () => {
    const id = generateUserId();
    expect(id).toMatch(/^user-/);
  });

  it("should generate unique IDs", () => {
    const ids = new Set(Array.from({ length: 50 }, () => generateUserId()));
    expect(ids.size).toBe(50);
  });
});

describe("generateUserName", () => {
  it("should return a non-empty string", () => {
    const name = generateUserName();
    expect(name.length).toBeGreaterThan(0);
  });

  it("should return one of the predefined names", () => {
    const validNames = [
      "Hari", "John", "Alex", "Sam", "Jade", "Max", "Eve",
      "Zoe", "Leo", "Luna", "Mia", "Noah", "Ivy", "Ray",
      "Kai", "Skye", "Finn", "Wren", "Ash", "Pip",
    ];
    const name = generateUserName();
    expect(validNames).toContain(name);
  });
});

describe("generateUserColor", () => {
  it("should return a valid hex color", () => {
    const color = generateUserColor();
    expect(color).toMatch(/^#[0-9A-Fa-f]{6}$/);
  });

  it("should return one of the predefined colors", () => {
    const validColors = [
      "#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7",
      "#DDA0DD", "#98D8C8", "#F7DC6F", "#BB8FCE", "#85C1E9",
      "#F1948A", "#82E0AA", "#F8C471", "#AED6F1", "#D7BDE2",
      "#A3E4D7", "#FAD7A0", "#A9CCE3", "#D5F5E3", "#FADBD8",
    ];
    const color = generateUserColor();
    expect(validColors).toContain(color);
  });
});
