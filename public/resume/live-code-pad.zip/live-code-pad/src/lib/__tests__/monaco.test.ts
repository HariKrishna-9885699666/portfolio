import { describe, it, expect } from "vitest";
import {
  LANGUAGES,
  DEFAULT_LANGUAGE,
  DEFAULT_CODE,
  getLanguageById,
} from "@/lib/monaco";

describe("LANGUAGES", () => {
  it("should have 2 languages", () => {
    expect(LANGUAGES).toHaveLength(2);
  });

  it("should include JavaScript and TypeScript", () => {
    const ids = LANGUAGES.map((l) => l.id);
    expect(ids).toContain("javascript");
    expect(ids).toContain("typescript");
  });

  it("should have unique IDs", () => {
    const ids = LANGUAGES.map((l) => l.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("should have labels and monacoLanguage for each entry", () => {
    for (const lang of LANGUAGES) {
      expect(lang.label).toBeTruthy();
      expect(lang.monacoLanguage).toBeTruthy();
    }
  });
});

describe("DEFAULT_LANGUAGE", () => {
  it("should be javascript", () => {
    expect(DEFAULT_LANGUAGE).toBe("javascript");
  });
});

describe("DEFAULT_CODE", () => {
  it("should have code for all languages", () => {
    for (const lang of LANGUAGES) {
      expect(DEFAULT_CODE[lang.id]).toBeDefined();
      expect(DEFAULT_CODE[lang.id].length).toBeGreaterThan(0);
    }
  });

  it("should have javascript code containing a function", () => {
    expect(DEFAULT_CODE.javascript).toContain("function");
  });

  it("should have typescript code with an interface", () => {
    expect(DEFAULT_CODE.typescript).toContain("interface");
  });


});

describe("getLanguageById", () => {
  it("should return javascript for a valid id", () => {
    const result = getLanguageById("javascript");
    expect(result.monacoLanguage).toBe("javascript");
  });

  it("should return the first language (javascript) for an unknown id", () => {
    // @ts-expect-error - testing invalid input
    const result = getLanguageById("unknown");
    expect(result.id).toBe("javascript");
  });
});
