import { nanoid, customAlphabet } from "nanoid";

const lowercaseNanoid = customAlphabet(
  "abcdefghijklmnopqrstuvwxyz0123456789",
  6,
);

export function generateRoomId(): string {
  return nanoid(9);
}

/**
 * Generates a human-readable session room ID that includes the candidate name.
 * Format: "hari-krishna-live-code-test-a7x92k"
 * - Candidate name is slugified (lowercased, spaces→hyphens, special chars removed)
 * - "live-code-test" suffix for readability
 * - 6-char unique identifier to avoid collisions
 */
export function generateSessionRoomId(candidateName: string): string {
  const slug = candidateName
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")  // remove special characters
    .replace(/\s+/g, "-")          // spaces to hyphens
    .replace(/-+/g, "-")           // collapse multiple hyphens
    .replace(/^-|-$/g, "");        // trim leading/trailing hyphens

  // Use lowercase-only alphabet so the entire slug stays lowercase
  const uniqueId = lowercaseNanoid();
  return `${slug || "candidate"}-live-code-test-${uniqueId}`;
}

const NAMES = [
  "Hari", "John", "Alex", "Sam", "Jade", "Max", "Eve",
  "Zoe", "Leo", "Luna", "Mia", "Noah", "Ivy", "Ray",
  "Kai", "Skye", "Finn", "Wren", "Ash", "Pip",
];

const COLORS = [
  "#FF6B6B", "#4ECDC4", "#45B7D1", "#96CEB4", "#FFEAA7",
  "#DDA0DD", "#98D8C8", "#F7DC6F", "#BB8FCE", "#85C1E9",
  "#F1948A", "#82E0AA", "#F8C471", "#AED6F1", "#D7BDE2",
  "#A3E4D7", "#FAD7A0", "#A9CCE3", "#D5F5E3", "#FADBD8",
];

export function generateUserName(): string {
  return NAMES[Math.floor(Math.random() * NAMES.length)];
}

export function generateUserColor(): string {
  return COLORS[Math.floor(Math.random() * COLORS.length)];
}

export function generateUserId(): string {
  return `user-${nanoid(6)}`;
}
