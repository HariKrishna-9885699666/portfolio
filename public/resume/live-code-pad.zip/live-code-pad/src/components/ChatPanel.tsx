"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { Send, MessageSquare } from "lucide-react";
import type { ChatMessage } from "@/types/editor";

interface ChatPanelProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  disabled?: boolean;
  placeholder?: string;
  title?: string;
}

export function ChatPanel({
  messages,
  onSendMessage,
  disabled = false,
  placeholder = "Type a message...",
  title = "Chat",
}: ChatPanelProps) {
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = useCallback(() => {
    const text = input.trim();
    if (!text || disabled) return;
    onSendMessage(text);
    setInput("");
    // Re-focus input after sending
    inputRef.current?.focus();
  }, [input, disabled, onSendMessage]);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSend();
      }
    },
    [handleSend],
  );

  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    const hours = date.getHours().toString().padStart(2, "0");
    const minutes = date.getMinutes().toString().padStart(2, "0");
    return `${hours}:${minutes}`;
  };

  return (
    <div className="flex flex-col h-full bg-[#1e1e1e]">
      {/* Header */}
      <div className="flex items-center gap-2 px-4 py-2.5 bg-[#252526] border-b border-[#333] shrink-0">
        <MessageSquare className="w-4 h-4 text-indigo-400" />
        <span className="text-xs font-semibold text-gray-300">{title}</span>
        {messages.length > 0 && (
          <span className="text-[10px] text-gray-500 ml-auto">
            {messages.length} message{messages.length !== 1 ? "s" : ""}
          </span>
        )}
      </div>

      {/* Messages area */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-3 space-y-2"
      >
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <MessageSquare className="w-8 h-8 text-gray-700 mb-3" />
            <p className="text-sm text-gray-500">No messages yet</p>
            <p className="text-xs text-gray-600 mt-1">
              Start the conversation with your candidate
            </p>
          </div>
        ) : (
          messages.map((msg) => {
            const isAdmin = msg.senderId === "admin";
            return (
              <div
                key={msg.id}
                className={`flex ${isAdmin ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[85%] rounded-xl px-3.5 py-2.5 ${
                    isAdmin
                      ? "bg-indigo-500/20 border border-indigo-500/20 rounded-br-md"
                      : "bg-[#2d2d2d] border border-[#444] rounded-bl-md"
                  }`}
                >
                  {/* Sender name (for non-admin messages) */}
                  {!isAdmin && (
                    <div className="text-[10px] text-indigo-400 font-medium mb-1 uppercase tracking-wider">
                      {msg.senderName || "Candidate"}
                    </div>
                  )}

                  <p className="text-sm text-gray-200 whitespace-pre-wrap break-words leading-relaxed">
                    {msg.text}
                  </p>

                  <div
                    className={`flex items-center gap-1 mt-1 ${
                      isAdmin ? "justify-end" : "justify-start"
                    }`}
                  >
                    <span className="text-[10px] text-gray-500">
                      {formatTime(msg.timestamp)}
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Input area */}
      <div className="p-3 border-t border-[#333] bg-[#252526]">
        <div className="flex items-center gap-2">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={disabled ? "Chat unavailable" : placeholder}
            disabled={disabled}
            className="flex-1 px-3.5 py-2.5 rounded-lg bg-[#1e1e1e] border border-[#444] text-sm text-gray-200 placeholder:text-gray-600 focus:border-indigo-500 focus:outline-none transition-colors disabled:opacity-50"
          />
          <button
            onClick={handleSend}
            disabled={disabled || !input.trim()}
            className="p-2.5 rounded-lg bg-indigo-500 text-white hover:bg-indigo-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.95]"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        <p className="text-[10px] text-gray-600 mt-1.5 px-1">
          Press Enter to send
        </p>
      </div>
    </div>
  );
}
