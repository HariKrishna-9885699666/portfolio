"use client";

import { useEffect, useCallback } from "react";
import { useYjs } from "@/providers/YjsProvider";
import { useSelf } from "@liveblocks/react";
import { UserCheck } from "lucide-react";

interface InterviewModeProps {
  isActive: boolean;
  onToggle: () => void;
}

export function InterviewMode({ isActive, onToggle }: InterviewModeProps) {
  const { yDoc } = useYjs();
  const self = useSelf();

  // Enable interview mode (sets initial state in Yjs)
  const handleEnable = useCallback(() => {
    const map = yDoc.getMap("interview");
    map.set("isActive", true);
    map.set("interviewerId", self?.id ?? null);
    map.set("candidateName", "");
    map.set("isReadOnly", false);
    map.set("timerDuration", null);
    map.set("timerStartedAt", null);
    map.set("status", "idle");
  }, [yDoc, self]);

  // Disable interview mode
  const handleDisable = useCallback(() => {
    const map = yDoc.getMap("interview");
    map.set("isActive", false);
    map.set("interviewerId", null);
    map.set("candidateName", "");
    map.set("isReadOnly", false);
    map.set("timerDuration", null);
    map.set("timerStartedAt", null);
    map.set("status", "idle");
  }, [yDoc]);

  const handleClick = useCallback(() => {
    if (!isActive) {
      handleEnable();
    } else {
      handleDisable();
    }
    onToggle();
  }, [isActive, handleEnable, handleDisable, onToggle]);

  return (
    <button
      onClick={handleClick}
      className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
        isActive
          ? "bg-indigo-500/20 text-indigo-400 border border-indigo-500/30"
          : "bg-[#2d2d2d] text-gray-300 border border-[#444] hover:border-indigo-500/50 hover:text-indigo-400"
      }`}
    >
      <UserCheck className="w-4 h-4" />
      <span>{isActive ? "Interview On" : "Interview Mode"}</span>
    </button>
  );
}
