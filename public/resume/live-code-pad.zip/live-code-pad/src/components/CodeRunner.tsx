"use client";

import { useState, useCallback, useEffect, useRef } from "react";
import {
  Play,
  Terminal,
  Loader2,
  X,
} from "lucide-react";
import type { SupportedLanguage, ExecutionRecord, LogEntry } from "@/types/editor";

interface CodeRunnerProps {
  code: string;
  codeRef?: React.MutableRefObject<string>; // Always-in-sync ref for reliable code reading
  language: SupportedLanguage;
  onExecutionComplete?: (record: ExecutionRecord) => void;
}

const SUPPORTED_LANGUAGES: SupportedLanguage[] = [
  "javascript",
  "typescript",
];

// Direct code executor — runs code in-page using new Function()
function CodeExecutor({ code, codeRef, runId, onExecutionComplete }: { code: string; codeRef?: React.MutableRefObject<string>; language: SupportedLanguage; runId: number; onExecutionComplete?: (record: ExecutionRecord) => void }) {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [status, setStatus] = useState<"idle" | "running" | "done" | "error">("idle");
  const logId = useRef(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const executedRunIdRef = useRef(0); // Prevents StrictMode double-execution
  const effectiveCodeRef = useRef(code); // Fallback when codeRef not provided
  // Always sync with the latest code from either source
  effectiveCodeRef.current = codeRef?.current ?? code;

  // Execute code when runId > 0
  useEffect(() => {
    if (runId === 0) {
      setLogs([]);
      setStatus("idle");
      logId.current = 0;
      executedRunIdRef.current = 0;
      return;
    }

    // Prevent React StrictMode double-mount from firing twice
    if (executedRunIdRef.current === runId) return;
    executedRunIdRef.current = runId;

    setLogs([]);
    setStatus("running");
    logId.current = 0;

    // Execute code asynchronously so the UI can show "Running..." first
    const run = async () => {
      const capturedLogs: LogEntry[] = [];
      let capturedError: string | null = null;

      // Override console methods to capture output
      const origConsole: Record<string, (...args: unknown[]) => void> = {};
      const methods = ["log", "warn", "error", "info"] as const;
      for (const m of methods) {
        origConsole[m] = console[m].bind(console);
        console[m] = (...args: unknown[]) => {
          const text = args
            .map((a) => (typeof a === "string" ? a : JSON.stringify(a, null, 2)))
            .join(" ");
          const logType = m === "error" ? "error" as const
            : m === "warn" ? "warn" as const
            : m === "info" ? "info" as const
            : "log" as const;
          capturedLogs.push({
            id: ++logId.current,
            type: logType,
            message: text,
            timestamp: Date.now(),
          });
          origConsole[m](...args);
        };
      }

      // Override unhandled promise rejections (catches async errors from user code)
      const origOnRejection = window.onunhandledrejection;
      window.onunhandledrejection = (e: PromiseRejectionEvent) => {
        capturedError = "Unhandled: " + (e.reason?.stack || String(e.reason));
      };

      try {
        // Read latest code from ref (always in sync, even if React state is stale)
        const codeToExecute = effectiveCodeRef.current;
        // Execute synchronous code using new Function()
        const fn = new Function(codeToExecute);
        const result = fn();

        // Handle async results (Promise, thenable)
        if (result && typeof result.then === "function") {
          await Promise.resolve(result);
        }
      } catch (e: unknown) {
        capturedError = e instanceof Error ? (e.stack || e.message) : String(e);
      } finally {
        // Restore original console methods
        for (const m of methods) {
          console[m] = origConsole[m];
        }
        window.onunhandledrejection = origOnRejection;
      }

      // Batch update logs and status
      const finalStatus: "done" | "error" = capturedError ? "error" : "done";
      if (capturedError) {
        capturedLogs.push({
          id: ++logId.current,
          type: "error",
          message: capturedError,
          timestamp: Date.now(),
        });
      } else {
        if (capturedLogs.length === 0) {
          capturedLogs.push({
            id: ++logId.current,
            type: "log",
            message: "Execution completed (no output)",
            timestamp: Date.now(),
          });
        }
      }
      setLogs(capturedLogs);
      setStatus(finalStatus);

      // Record execution in history
      onExecutionComplete?.({
        id: String(runId),
        timestamp: Date.now(),
        code: effectiveCodeRef.current,
        output: capturedLogs,
        status: finalStatus,
      });
    };

    // Use a microtask delay so the UI has time to show "Running..."
    // before the synchronous code executes
    void Promise.resolve().then(run);
    // Only depend on runId — code/language changes should NOT auto-trigger
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runId]);

  // Auto-scroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="h-full flex flex-col">
      {/* Status bar */}
      <div className="flex items-center gap-2 px-4 py-1.5 bg-[#1e1e1e] border-b border-[#333] shrink-0 min-h-[34px]">
        <div className="flex-1" />
        {status === "running" && (
          <span className="flex items-center gap-1.5 text-xs text-amber-400">
            <Loader2 className="w-3 h-3 animate-spin" />
            Running...
          </span>
        )}
        {status === "done" && logs.length > 0 && (
          <span className="text-[10px] text-emerald-500 font-medium flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            Completed
          </span>
        )}
        {status === "error" && (
          <span className="text-[10px] text-red-400 font-medium flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
            Error
          </span>
        )}
        {status !== "idle" && logs.length > 0 && (
          <button
            onClick={() => { setLogs([]); setStatus("idle"); logId.current = 0; }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#2d2d2d] text-gray-300 border border-[#444] hover:bg-red-500/20 hover:text-red-400 hover:border-red-500/30 transition-all duration-150 text-xs font-medium active:scale-[0.96]"
            title="Clear all console output"
          >
            <X className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Clear Console</span>
          </button>
        )}
      </div>

      {/* Logs area */}
      <div ref={scrollRef} className="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed space-y-1.5">
        {status === "idle" && (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Terminal className="w-8 h-8 text-gray-600 mb-3" />
            <p className="text-gray-500 text-sm">Click <span className="text-emerald-400 font-semibold">Run Code</span> to execute</p>
            <p className="text-gray-600 text-[10px] mt-1">or press <kbd className="px-1.5 py-0.5 rounded bg-[#2d2d2d] border border-[#444] text-gray-500">Cmd + Enter</kbd></p>
          </div>
        )}
        {status === "running" && logs.length === 0 && (
          <div className="flex items-center justify-center h-full">
            <div className="flex items-center gap-2 text-gray-500">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Executing...</span>
            </div>
          </div>
        )}
        {logs.map((log) => (
          <div
            key={log.id}
            className={`whitespace-pre-wrap break-all leading-relaxed ${
              log.type === "error"
                ? "text-red-400"
                : log.type === "warn"
                  ? "text-amber-400"
                  : log.type === "result"
                    ? "text-emerald-400"
                    : "text-gray-200"
            }`}
          >
            {log.message}
          </div>
        ))}
      </div>
    </div>
  );
}

export function CodeRunner({ code, codeRef, language, onExecutionComplete }: CodeRunnerProps) {
  const [runId, setRunId] = useState(0);

  const isSupported = SUPPORTED_LANGUAGES.includes(language);

  const handleRun = useCallback(() => {
    setRunId((id) => id + 1);
  }, []);

  // Cmd+Enter keyboard shortcut
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
        e.preventDefault();
        if (isSupported) {
          setRunId((id) => id + 1);
        }
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isSupported]);

  if (!isSupported) {
    return (
      <div className="flex flex-col h-full bg-[#1e1e1e]">
        <div className="flex items-center justify-between px-4 py-2 bg-[#1e1e1e] border-b border-[#333]">
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <Terminal className="w-3.5 h-3.5" />
            <span>Code execution not supported for this language yet</span>
          </div>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <Terminal className="w-10 h-10 text-gray-700 mx-auto mb-3" />
            <p className="text-sm text-gray-600">Execution is available for JavaScript and TypeScript</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-[#1e1e1e]">
      {/* Toolbar */}
      <div className="flex items-center gap-3 px-4 py-2.5 bg-[#252526] border-b border-[#333] shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
            <Play className="w-3 h-3 text-white fill-white" />
          </div>
          <span className="text-xs font-semibold text-gray-300">Output</span>
        </div>

        <div className="flex-1" />

        <button
          onClick={handleRun}
          className="flex items-center gap-2 px-4 py-1.5 rounded-lg bg-emerald-500 text-white text-sm font-semibold hover:bg-emerald-400 active:bg-emerald-600 transition-all duration-150 shadow-lg shadow-emerald-500/25 hover:shadow-emerald-500/40 active:scale-[0.97]"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          Run Code
        </button>

        <kbd className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-[#2d2d2d] border border-[#444] text-[10px] text-gray-500 font-mono">
          <span className="text-[9px]">⌘</span>↵
        </kbd>
      </div>

      {/* Output content */}
      <div className="flex-1 min-h-0">
        <CodeExecutor
          code={code}
          codeRef={codeRef}
          language={language}
          runId={runId}
          onExecutionComplete={onExecutionComplete}
        />
      </div>
    </div>
  );
}
