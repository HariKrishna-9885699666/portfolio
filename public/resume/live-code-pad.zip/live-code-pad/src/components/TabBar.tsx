"use client";

import { useCallback } from "react";
import { Plus, X, FileCode } from "lucide-react";
import type { TabData } from "@/types/editor";

interface TabBarProps {
  tabs: TabData[];
  activeTabId: string;
  mode: "view" | "edit";
  onTabSelect: (tabId: string) => void;
  onTabCreate: () => void;
  onTabDelete: (tabId: string) => void;
}

export function TabBar({
  tabs,
  activeTabId,
  mode,
  onTabSelect,
  onTabCreate,
  onTabDelete,
}: TabBarProps) {
  const handleDelete = useCallback(
    (e: React.MouseEvent, tabId: string) => {
      e.stopPropagation();
      if (tabs.length <= 1) return;
      onTabDelete(tabId);
    },
    [tabs.length, onTabDelete],
  );

  return (
    <div className="flex items-center bg-[#252526] border-b border-[#3c3c3d] overflow-x-auto shrink-0">
      {/* Scrollable tab list */}
      <div className="flex items-center flex-1 min-w-0">
        {tabs.map((tab, i) => (
          <div
            key={tab.id}
            onClick={() => onTabSelect(tab.id)}
            className={`group relative flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium cursor-pointer select-none border-r border-[#3c3c3d] transition-colors min-w-0 shrink-0 ${
              tab.id === activeTabId
                ? "bg-[#1e1e1e] text-gray-200 border-t-[2px] border-t-indigo-500"
                : "bg-[#2d2d2d] text-gray-400 hover:text-gray-300 hover:bg-[#333]"
            }`}
          >
            <FileCode className="w-3 h-3 shrink-0" />
            <span className="truncate max-w-[120px]">tab{i + 1}</span>

            {/* Delete button (edit mode only, not on the last tab) */}
            {mode === "edit" && tabs.length > 1 && (
              <button
                onClick={(e) => handleDelete(e, tab.id)}
                className="opacity-0 group-hover:opacity-100 p-0.5 rounded hover:bg-red-500/20 hover:text-red-400 transition-all ml-0.5"
                title="Delete tab"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Add new tab button (edit mode only) */}
      {mode === "edit" && (
        <button
          onClick={onTabCreate}
          className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-gray-400 hover:text-gray-200 hover:bg-[#333] transition-colors shrink-0 border-l border-[#3c3c3d]"
          title="Add new tab"
        >
          <Plus className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">New Tab</span>
        </button>
      )}

      {/* Spacer to fill remaining space */}
      {mode === "view" && (
        <div className="flex-1 bg-[#252526] border-b border-[#3c3c3d] h-full" />
      )}
    </div>
  );
}
