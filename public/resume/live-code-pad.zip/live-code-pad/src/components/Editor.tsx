"use client";

import { useState, useCallback, useEffect, useRef } from "react";
import { RoomProvider, useSelf } from "@liveblocks/react";
import { YjsProvider, useYjs } from "@/providers/YjsProvider";
import { MonacoEditor } from "./MonacoEditor";
import { PresenceBar } from "./PresenceBar";
import { LanguageSelector } from "./LanguageSelector";
import { CopyLinkButton } from "./CopyLinkButton";
import { InterviewMode } from "./InterviewMode";
import { InterviewTimer } from "./InterviewTimer";
import { InterviewNotes } from "./InterviewNotes";
import { CodeRunner } from "./CodeRunner";
import { ChatPanel } from "./ChatPanel";
import {
  UserCheck,
  Lock,
  Unlock,
  ClipboardList,
  ChevronRight,
  MessageSquare,
  Wifi,
  WifiOff,
  Download,
  FileCheck,
} from "lucide-react";
import { downloadAllCode } from "@/lib/download";
import type {
  SupportedLanguage,
  TimerDuration,
  InterviewStatus,
  ChatMessage,
  ExecutionRecord,
  TimerEvent,
  TabData,
} from "@/types/editor";
import { nanoid } from "nanoid";
import { TabBar } from "./TabBar";

interface EditorProps {
  roomId: string;
}

function EditorContent({ roomId }: { roomId: string }) {
  const [language, setLanguage] = useState<SupportedLanguage>("javascript");
  const [interviewActive, setInterviewActive] = useState(false);
  const [notesOpen, setNotesOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [editorContent, setEditorContent] = useState("");
  const codeRef = useRef(""); // Always synced synchronously with editor content
  const [isReadOnly, setIsReadOnly] = useState(false);
  const [candidateName, setCandidateName] = useState("");
  const [interviewerId, setInterviewerId] = useState<string | null>(null);
  const [timerDuration, setTimerDuration] = useState<TimerDuration | null>(null);
  const [timerStartedAt, setTimerStartedAt] = useState<number | null>(null);
  const [timerStatus, setTimerStatus] = useState<InterviewStatus>("idle");
  const [notes, setNotes] = useState("");
  const [accessGranted, setAccessGranted] = useState(false);
  const [accessEverGranted, setAccessEverGranted] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [pendingChatCount, setPendingChatCount] = useState(0);
  const prevChatCountRef = useRef(0);
  const [tabs, setTabs] = useState<TabData[]>([]);
  const [activeTabId, setActiveTabId] = useState<string>("default");
  const [allTabContents, setAllTabContents] = useState<Record<string, string>>({});
  const tabInitRef = useRef(false);
  const { yDoc, connectionStatus, connectionError } = useYjs();
  const self = useSelf();

  const isInterviewer =
    interviewActive && interviewerId !== null && self?.id === interviewerId;

  // Sync access settings from Yjs — default to false (revoked until admin grants)
  // Uses lastAction to persist "revoked after being granted" across page refreshes
  useEffect(() => {
    const accessMap = yDoc.getMap("access-settings");
    const onChange = () => {
      const granted = (accessMap.get("accessGranted") as boolean) ?? false;
      setAccessGranted(granted);
      // Track if access was EVER granted (to show different messages)
      if (granted) {
        setAccessEverGranted(true);
      }
      // Check persisted everGranted — survives page refreshes
      const everGranted = accessMap.get("everGranted") as boolean | undefined;
      if (everGranted) {
        setAccessEverGranted(true);
      }
    };
    accessMap.observeDeep(onChange);
    onChange();
    return () => accessMap.unobserveDeep(onChange);
  }, [yDoc]);

  // Handle language changes — sync to Yjs so admin sees correct syntax
  const handleLanguageChange = useCallback(
    (newLanguage: SupportedLanguage) => {
      setLanguage(newLanguage);
      // Sync language to Yjs interview map
      const interviewMap = yDoc.getMap("interview");
      interviewMap.set("language", newLanguage);
    },
    [yDoc],
  );

  // Sync interview state from Yjs Map
  useEffect(() => {
    const interviewMap = yDoc.getMap("interview");
    const onChange = () => {
      setInterviewActive((interviewMap.get("isActive") as boolean) ?? false);
      // Sync language from Yjs (admin sets it)
      const yLang = interviewMap.get("language") as SupportedLanguage | undefined;
      if (yLang) {
        setLanguage(yLang);
      }
      setCandidateName(
        (interviewMap.get("candidateName") as string) ?? "",
      );
      setInterviewerId(
        (interviewMap.get("interviewerId") as string) ?? null,
      );
      setIsReadOnly(
        (interviewMap.get("isReadOnly") as boolean) ?? false,
      );
      setTimerDuration(
        (interviewMap.get("timerDuration") as TimerDuration) ?? null,
      );
      setTimerStartedAt(
        (interviewMap.get("timerStartedAt") as number) ?? null,
      );
      setTimerStatus(
        (interviewMap.get("status") as InterviewStatus) ?? "idle",
      );
    };
    interviewMap.observeDeep(onChange);
    onChange();
    return () => interviewMap.unobserveDeep(onChange);
  }, [yDoc]);

  // Sync notes from Yjs Text
  useEffect(() => {
    const notesText = yDoc.getText("notes");
    const onChange = () => setNotes(notesText.toString());
    notesText.observe(onChange);
    onChange();
    return () => notesText.unobserve(onChange);
  }, [yDoc]);

  // Sync chat messages from Yjs
  useEffect(() => {
    const chatArray = yDoc.getArray<ChatMessage>("chat-messages");
    const onChange = () => {
      const msgs = chatArray.toArray();
      setChatMessages(msgs);
    };
    chatArray.observe(onChange);
    onChange();
    return () => chatArray.unobserve(onChange);
  }, [yDoc]);

  // Initialize default tab if tabs array is empty
  useEffect(() => {
    if (connectionStatus !== "connected") return;
    if (tabInitRef.current) return;
    tabInitRef.current = true;

    const tabsArray = yDoc.getArray<TabData>("tabs");
    if (tabsArray.length === 0) {
      const defaultTab: TabData = { id: "default", name: "Tab 1", createdAt: Date.now() };
      tabsArray.push([defaultTab]);

      // Set default tab as active
      const activeTabMap = yDoc.getMap("activeTab");
      activeTabMap.set("id", "default");

      // Migrate any existing content from old "monaco" yText
      const oldYText = yDoc.getText("monaco");
      if (oldYText.toString()) {
        const newYText = yDoc.getText("tab-content-default");
        newYText.insert(0, oldYText.toString());
        oldYText.delete(0, oldYText.length);
      }
    } else {
      // Tabs already exist — just ensure active tab is set
      const activeTabMap = yDoc.getMap("activeTab");
      if (!activeTabMap.get("id")) {
        activeTabMap.set("id", tabsArray.get(0)!.id);
      }
    }
  }, [connectionStatus, yDoc]);

  // Sync tabs from Yjs
  useEffect(() => {
    const tabsArray = yDoc.getArray<TabData>("tabs");
    const onChange = () => {
      const newTabs = tabsArray.toArray();
      setTabs(newTabs);
    };
    tabsArray.observe(onChange);
    onChange();
    return () => tabsArray.unobserve(onChange);
  }, [yDoc]);

  // Sync active tab from Yjs
  useEffect(() => {
    const activeTabMap = yDoc.getMap("activeTab");
    const onChange = () => {
      const id = activeTabMap.get("id") as string | undefined;
      if (id) setActiveTabId(id);
    };
    activeTabMap.observeDeep(onChange);
    onChange();
    return () => activeTabMap.unobserveDeep(onChange);
  }, [yDoc]);

  // Sync all tab contents (for session-end view and download)
  useEffect(() => {
    const contents: Record<string, string> = {};
    tabs.forEach((tab) => {
      const yText = yDoc.getText("tab-content-" + tab.id);
      contents[tab.id] = yText.toString();
    });
    setAllTabContents(contents);

    // Observe all tab yTexts
    const observers = tabs.map((tab) => {
      const yText = yDoc.getText("tab-content-" + tab.id);
      const onChange = () => {
        setAllTabContents((prev) => ({
          ...prev,
          [tab.id]: yText.toString(),
        }));
      };
      yText.observe(onChange);
      return { yText, onChange };
    });

    return () => {
      observers.forEach(({ yText, onChange }) => yText.unobserve(onChange));
    };
  }, [yDoc, tabs]);

  // Track unread messages when chat is closed
  useEffect(() => {
    if (!chatOpen && chatMessages.length > prevChatCountRef.current) {
      setPendingChatCount((c) => c + (chatMessages.length - prevChatCountRef.current));
    }
    prevChatCountRef.current = chatMessages.length;
    if (chatOpen) {
      setPendingChatCount(0);
    }
  }, [chatMessages.length, chatOpen]);

  // Handle interview toggle from InterviewMode component
  const handleInterviewToggle = useCallback(() => {
    setNotesOpen(false);
  }, []);

  // Track editor content — update ref synchronously AND state for re-renders
  const handleContentChange = useCallback((content: string) => {
    codeRef.current = content;
    setEditorContent(content);
  }, []);

  // Toggle read-only (interviewer only)
  const handleToggleReadOnly = useCallback(() => {
    if (!isInterviewer) return;
    yDoc.getMap("interview").set("isReadOnly", !isReadOnly);
  }, [yDoc, isInterviewer, isReadOnly]);

  // Start timer
  const handleStartTimer = useCallback(
    (duration: TimerDuration) => {
      if (!isInterviewer) return;
      const map = yDoc.getMap("interview");
      map.set("timerDuration", duration);
      map.set("timerStartedAt", Date.now());
      map.set("status", "running");
      // Record timer event
      const events = yDoc.getArray<TimerEvent>("timer-events");
      events.push([{ type: "start", timestamp: Date.now(), duration }]);
    },
    [yDoc, isInterviewer],
  );

  // Stop timer
  const handleStopTimer = useCallback(() => {
    if (!isInterviewer) return;
    const map = yDoc.getMap("interview");
    map.set("status", "finished");
    map.set("isReadOnly", true);
    // Record timer event
    const events = yDoc.getArray<TimerEvent>("timer-events");
    events.push([{ type: "stop", timestamp: Date.now() }]);
  }, [yDoc, isInterviewer]);

  // Handle timer expiry
  useEffect(() => {
    if (timerStatus !== "running" || !timerStartedAt || !timerDuration || !isInterviewer) return;

    const check = () => {
      const elapsed = Date.now() - timerStartedAt;
      const total = timerDuration * 60 * 1000;
      if (elapsed >= total) {
        const map = yDoc.getMap("interview");
        map.set("status", "finished");
        map.set("isReadOnly", true);
        // Record timer expired event
        const events = yDoc.getArray<TimerEvent>("timer-events");
        events.push([{ type: "expired", timestamp: Date.now() }]);
      }
    };
    check();
    const interval = setInterval(check, 1000);
    return () => clearInterval(interval);
  }, [timerStatus, timerStartedAt, timerDuration, yDoc, isInterviewer]);

  // Update candidate name
  const handleNameChange = useCallback(
    (name: string) => {
      if (!isInterviewer) return;
      const nameText = yDoc.getText("candidateName");
      nameText.delete(0, nameText.length);
      nameText.insert(0, name);
    },
    [yDoc, isInterviewer],
  );

  // Update notes
  const handleNotesChange = useCallback(
    (newNotes: string) => {
      if (!isInterviewer) return;
      const notesText = yDoc.getText("notes");
      notesText.delete(0, notesText.length);
      notesText.insert(0, newNotes);
    },
    [yDoc, isInterviewer],
  );

  // Record execution history in Yjs
  const handleExecutionComplete = useCallback(
    (record: ExecutionRecord) => {
      const execArray = yDoc.getArray<ExecutionRecord>("execution-history");
      // Keep only the last 50 executions to prevent unbounded growth
      const current = execArray.toArray();
      if (current.length >= 50) {
        execArray.delete(0, current.length - 49);
      }
      execArray.push([record]);
    },
    [yDoc],
  );

  // Send chat message (candidate side)
  const handleSendMessage = useCallback(
    (text: string) => {
      const chatArray = yDoc.getArray<ChatMessage>("chat-messages");
      const senderName = (self?.info?.name as string) ?? "Candidate";
      const message: ChatMessage = {
        id: nanoid(8),
        senderId: self?.id ?? "candidate",
        senderName,
        text,
        timestamp: Date.now(),
      };
      chatArray.push([message]);
    },
    [yDoc, self],
  );

  // Access denied view — different messages for "not yet granted" vs "revoked"
  if (!accessGranted) {
    const wasRevoked = accessEverGranted; // Was granted before, now revoked
    return (
      <div className="flex flex-col h-screen bg-[#1e1e1e]">
        {/* Minimal header */}
        <header className="flex items-center justify-between px-4 py-2 bg-[#252526] border-b border-[#3c3c3d] shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <span className="text-xs font-bold text-white">{">"}</span>
            </div>
            <span className="text-sm font-semibold text-gray-200">
              CodePad
            </span>
          </div>
          {/* Show candidate name even on access denied view */}
          <div className="flex items-center gap-3">
            {candidateName && (
              <span className="text-xs text-gray-500">
                {candidateName}
              </span>
            )}
            <CopyLinkButton roomId={roomId} />
          </div>
        </header>

        <div className="flex-1 flex items-center justify-center p-6">
          <div className="max-w-md text-center">
            <div className={`w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 border ${
              wasRevoked
                ? "bg-red-500/10 border-red-500/20"
                : "bg-amber-500/10 border-amber-500/20"
            }`}>
              <Lock className={`w-10 h-10 ${wasRevoked ? "text-red-400" : "text-amber-400"}`} />
            </div>
            <h2 className="text-2xl font-bold text-gray-200 mb-3">
              {wasRevoked ? "Access Revoked" : "Access Restricted"}
            </h2>
            {wasRevoked ? (
              <p className="text-gray-400 text-lg leading-relaxed">
                Your access to this interview session has been revoked by the administrator.
              </p>
            ) : (
              <p className="text-gray-500 text-lg leading-relaxed">
                You do not have access to this interview session.
              </p>
            )}
            <p className="text-gray-600 text-sm mt-4">
              Please contact the administrator for assistance.
            </p>
            {connectionStatus === "connected" && !wasRevoked && (
              <div className="flex items-center justify-center gap-2 mt-6 text-xs text-emerald-400 bg-emerald-400/5 rounded-lg px-4 py-2 border border-emerald-500/10">
                <Wifi className="w-3 h-3" />
                <span>Session is live — waiting for access to be granted...</span>
              </div>
            )}
            {connectionStatus === "connected" && wasRevoked && (
              <div className="flex items-center justify-center gap-2 mt-6 text-xs text-amber-400 bg-amber-400/5 rounded-lg px-4 py-2 border border-amber-500/10">
                <Wifi className="w-3 h-3" />
                <span>Session is live — access has been revoked.</span>
              </div>
            )}
            {connectionStatus === "connecting" && (
              <div className="flex items-center justify-center gap-2 mt-6 text-xs text-amber-400 bg-amber-400/5 rounded-lg px-4 py-2 border border-amber-500/10">
                <div className="w-3 h-3 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                <span>Connecting to session...</span>
              </div>
            )}
            {connectionStatus === "disconnected" && (
              <div className="flex items-center justify-center gap-2 mt-6 text-xs text-red-400 bg-red-400/5 rounded-lg px-4 py-2 border border-red-500/10">
                <WifiOff className="w-3 h-3" />
                <span>Disconnected. Reconnecting...</span>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-[#1e1e1e]">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-2 bg-[#252526] border-b border-[#3c3c3d] shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <span className="text-xs font-bold text-white">{">"}</span>
            </div>
            <span className="text-sm font-semibold text-gray-200">
              CodePad
            </span>
          </div>
          {/* Show candidate name when set (always visible, not tied to interview mode) */}
          {candidateName && (
            <>
              <div className="h-4 w-px bg-[#3c3c3d]" />
              <div className="flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5 text-indigo-400" />
                <span className="text-sm font-medium text-gray-200">
                  {candidateName}
                </span>
                {!isInterviewer && (
                  <span className="text-[10px] text-gray-500 bg-[#2d2d2d] px-1.5 py-0.5 rounded">
                    Interview
                  </span>
                )}
              </div>
            </>
          )}
          <div className="h-4 w-px bg-[#3c3c3d]" />
          <span className="text-xs text-gray-500 font-mono">
            room/{roomId}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Chat toggle - always available, before interview controls */}
          <button
            onClick={() => setChatOpen(!chatOpen)}
            className={`relative flex items-center gap-1.5 px-2 py-1.5 rounded-md text-xs font-medium transition-colors ${
              chatOpen
                ? "bg-indigo-500/20 text-indigo-400 border border-indigo-500/30"
                : "bg-[#2d2d2d] text-gray-300 border border-[#444] hover:border-indigo-500/50 hover:text-indigo-400"
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Chat</span>
            {pendingChatCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-indigo-500 text-white text-[9px] font-bold flex items-center justify-center">
                {pendingChatCount > 9 ? "9+" : pendingChatCount}
              </span>
            )}
          </button>
          <LanguageSelector language={language} onChange={handleLanguageChange} />
          <InterviewMode
            isActive={interviewActive}
            onToggle={handleInterviewToggle}
          />
          {/* Connection indicator */}
          <div
            className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium ${
              connectionStatus === "connected"
                ? "bg-emerald-400/10 text-emerald-400"
                : connectionStatus === "disconnected"
                  ? "bg-red-400/10 text-red-400"
                  : "bg-amber-400/10 text-amber-400"
            }`}
            title={connectionError || `Collaboration: ${connectionStatus}`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                connectionStatus === "connected"
                  ? "bg-emerald-400"
                  : connectionStatus === "disconnected"
                    ? "bg-red-400"
                    : "bg-amber-400 animate-pulse"
              }`}
            />
            <span>
              {connectionStatus === "connected"
                ? "Live"
                : connectionStatus === "disconnected"
                  ? "Offline"
                  : "Connecting..."}
            </span>
          </div>

          <CopyLinkButton roomId={roomId} />
          <PresenceBar />
        </div>
      </header>

      {/* Interview mode bar (shown when active) */}
      {interviewActive && (
        <div className="flex items-center gap-3 px-4 py-1.5 bg-[#1e1e1e] border-b border-[#3c3c3d] shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
            <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">
              Interview
            </span>
          </div>

          <div className="h-3 w-px bg-[#3c3c3d]" />

          {/* Candidate name */}
          <div className="flex items-center gap-2">
            <UserCheck className="w-3.5 h-3.5 text-gray-500 shrink-0" />
            {isInterviewer ? (
              <input
                type="text"
                value={candidateName}
                onChange={(e) => handleNameChange(e.target.value)}
                placeholder="Candidate name..."
                className="w-32 bg-transparent text-sm text-gray-200 border-b border-transparent hover:border-[#555] focus:border-indigo-500 outline-none transition-colors placeholder:text-gray-600"
              />
            ) : (
              <span className="text-sm text-gray-200">
                {candidateName || "Candidate"}
              </span>
            )}
          </div>

          <div className="h-3 w-px bg-[#3c3c3d]" />

          {/* Read-only toggle (interviewer only) */}
          {isInterviewer && (
            <button
              onClick={handleToggleReadOnly}
              className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium transition-colors ${
                isReadOnly
                  ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                  : "bg-[#2d2d2d] text-gray-400 border border-[#444] hover:text-gray-200"
              }`}
            >
              {isReadOnly ? (
                <>
                  <Lock className="w-3 h-3" />
                  <span>Read-Only</span>
                </>
              ) : (
                <>
                  <Unlock className="w-3 h-3" />
                  <span>Editable</span>
                </>
              )}
            </button>
          )}
          {!isInterviewer && isReadOnly && (
            <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-medium">
              <Lock className="w-3 h-3" />
              <span>Read-Only</span>
            </div>
          )}

          <div className="h-3 w-px bg-[#3c3c3d]" />

          {/* Timer */}
          <InterviewTimer
            duration={timerDuration}
            startedAt={timerStartedAt}
            status={timerStatus}
            isInterviewer={isInterviewer}
            onStart={handleStartTimer}
            onStop={handleStopTimer}
          />

          <div className="flex-1" />

          {/* Notes toggle */}
          <button
            onClick={() => setNotesOpen(!notesOpen)}
            className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium transition-colors ${
              notesOpen
                ? "bg-indigo-500/20 text-indigo-400 border border-indigo-500/30"
                : "bg-[#2d2d2d] text-gray-400 border border-[#444] hover:text-gray-200"
            }`}
          >
            <ClipboardList className="w-3.5 h-3.5" />
            <span>Notes</span>
            <ChevronRight
              className={`w-3 h-3 transition-transform ${
                notesOpen ? "rotate-90" : ""
              }`}
            />
          </button>
        </div>
      )}

      {/* Code tab bar - candidate can add/delete tabs */}
      {tabs.length > 0 && timerStatus !== "finished" && (
        <TabBar
          tabs={tabs}
          activeTabId={activeTabId}
          mode="edit"
          onTabSelect={(id) => {
            const activeTabMap = yDoc.getMap("activeTab");
            activeTabMap.set("id", id);
          }}
          onTabCreate={() => {
            const tabsArray = yDoc.getArray<TabData>("tabs");
            const newId = nanoid(8);
            const newTab: TabData = { id: newId, name: "", createdAt: Date.now() };
            tabsArray.push([newTab]);
            const activeTabMap = yDoc.getMap("activeTab");
            activeTabMap.set("id", newId);
          }}
          onTabDelete={(tabId) => {
            const tabsArray = yDoc.getArray<TabData>("tabs");
            for (let i = 0; i < tabsArray.length; i++) {
              const tab = tabsArray.get(i);
              if (tab?.id === tabId) {
                tabsArray.delete(i, 1);
                const tabYText = yDoc.getText("tab-content-" + tabId);
                tabYText.delete(0, tabYText.length);
                break;
              }
            }
            const activeTabMap = yDoc.getMap("activeTab");
            if (activeTabMap.get("id") === tabId) {
              const remaining = tabsArray.toArray();
              if (remaining.length > 0) {
                activeTabMap.set("id", remaining[0].id);
              }
            }
          }}
        />
      )}

      {/* Content area */}
      <div className="flex flex-row flex-1 min-h-0">
        {/* Editor panel - left side */}
        <div className="flex flex-col flex-1 min-w-0">
          {timerStatus === "finished" ? (
            /* Session Complete View */
            <SessionCompleteView
              candidateName={candidateName}
              tabs={tabs}
              tabContents={allTabContents}
              language={language}
              roomId={roomId}
            />
          ) : (
            <MonacoEditor
              language={language}
              tabId={activeTabId}
              readOnly={isReadOnly}
              onContentChange={handleContentChange}
            />
          )}
        </div>

        {/* Vertical divider */}
        <div className="w-px bg-[#333] shrink-0" />

        {/* Right panels: output + optional chat/notes */}
        <div className={`flex flex-col ${chatOpen || (interviewActive && notesOpen) ? "w-[55%]" : "w-[45%]"} min-w-[380px] max-w-[55%]`}>
          {/* Code output */}
          <div className="flex-1 min-h-0">
            <CodeRunner
              code={editorContent}
              codeRef={codeRef}
              language={language}
              onExecutionComplete={handleExecutionComplete}
            />
          </div>

          {/* Chat panel (below output, shown when toggled) */}
          {chatOpen && (
            <>
              <div className="h-px bg-[#333] shrink-0" />
              <div className="h-[250px] shrink-0">
                <ChatPanel
                  messages={chatMessages}
                  onSendMessage={handleSendMessage}
                  disabled={false}
                  placeholder="Type a message..."
                  title="Interview Chat"
                />
              </div>
            </>
          )}
        </div>

        {/* Notes sidebar (far right) */}
        {interviewActive && notesOpen && (
          <>
            <div className="w-px bg-[#333] shrink-0" />
            <InterviewNotes
              isOpen={notesOpen}
              onClose={() => setNotesOpen(false)}
              notes={notes}
              onNotesChange={handleNotesChange}
              isInterviewer={isInterviewer}
              editorContent={editorContent}
            />
          </>
        )}
      </div>
    </div>
  );
}

function SessionCompleteView({
  candidateName,
  tabs,
  tabContents,
  language,
  roomId,
}: {
  candidateName: string;
  tabs: TabData[];
  tabContents: Record<string, string>;
  language: string;
  roomId: string;
}) {
  const handleDownload = useCallback(() => {
    downloadAllCode({
      candidateName,
      tabs,
      tabContents,
      language,
      roomId,
    });
  }, [candidateName, tabs, tabContents, language, roomId]);

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-[#1e1e1e] overflow-y-auto">
      <div className="max-w-3xl w-full mx-auto p-6 md:p-10">
        {/* Completion badge */}
        <div className="flex items-center gap-4 mb-8">
          <div className="w-16 h-16 rounded-2xl bg-emerald-500/15 border border-emerald-500/20 flex items-center justify-center shrink-0">
            <FileCheck className="w-8 h-8 text-emerald-400" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-100">Session Complete</h2>
            <p className="text-gray-400 mt-1">
              The interview session has ended. You can review and download the code below.
            </p>
          </div>
        </div>

        {/* Session info */}
        <div className="flex flex-wrap gap-3 mb-8">
          <div className="bg-[#252526] rounded-lg px-3 py-2 border border-[#3c3c3d]">
            <span className="text-[10px] text-gray-600 uppercase tracking-wider block">Candidate</span>
            <span className="text-sm text-gray-200 font-medium">{candidateName}</span>
          </div>
          <div className="bg-[#252526] rounded-lg px-3 py-2 border border-[#3c3c3d]">
            <span className="text-[10px] text-gray-600 uppercase tracking-wider block">Language</span>
            <span className="text-sm text-gray-200 font-medium capitalize">{language}</span>
          </div>
          <div className="bg-[#252526] rounded-lg px-3 py-2 border border-[#3c3c3d]">
            <span className="text-[10px] text-gray-600 uppercase tracking-wider block">Tabs</span>
            <span className="text-sm text-gray-200 font-medium">{tabs.length}</span>
          </div>
        </div>

        {/* Download button */}
        <button
          onClick={handleDownload}
          className="w-full flex items-center justify-center gap-3 px-6 py-4 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold text-sm hover:from-indigo-400 hover:to-purple-500 transition-all duration-300 shadow-lg shadow-indigo-500/25 hover:shadow-indigo-500/40 active:scale-[0.98] mb-8"
        >
          <Download className="w-5 h-5" />
          <span>Download All Code Snippets</span>
        </button>

        {/* Tab cards */}
        <div className="space-y-4">
          <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider px-1">
            Code Review
          </h3>
          {tabs.map((tab) => {
            const code = tabContents[tab.id] || "";
            return (
              <div
                key={tab.id}
                className="rounded-xl border border-[#2a2a2a] bg-[#141414] overflow-hidden"
              >
                <div className="flex items-center gap-2 px-4 py-2.5 bg-[#1a1a1a] border-b border-[#2a2a2a]">
                  <div className="w-2 h-2 rounded-full bg-indigo-400" />
                  <span className="text-sm font-medium text-gray-200">
                    {tab.name}
                  </span>
                  <span className="text-[10px] text-gray-600 ml-auto font-mono">
                    {code.split("\n").length} lines
                  </span>
                </div>
                <pre className="p-4 text-sm font-mono text-gray-300 overflow-x-auto leading-relaxed">
                  <code>{code || <span className="text-gray-600 italic">Empty</span>}</code>
                </pre>
              </div>
            );
          })}
        </div>

        {/* Footer note */}
        <p className="text-xs text-gray-600 text-center mt-8">
          Generated by CodePad — All code from this session has been preserved for your reference.
        </p>
      </div>
    </div>
  );
}

export function Editor({ roomId }: EditorProps) {
  return (
    <RoomProvider
      id={roomId}
      initialPresence={{
        name: "",
        color: "",
        cursor: null,
        isOnline: true,
        lastActivity: Date.now(),
      }}
    >
      <YjsProvider>
        <EditorContent roomId={roomId} />
      </YjsProvider>
    </RoomProvider>
  );
}
