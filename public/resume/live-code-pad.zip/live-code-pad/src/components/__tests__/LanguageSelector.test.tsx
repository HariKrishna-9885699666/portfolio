import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { LanguageSelector } from "@/components/LanguageSelector";
import { LANGUAGES } from "@/lib/monaco";

describe("LanguageSelector", () => {
  it("should render with the current language label", () => {
    render(
      <LanguageSelector language="javascript" onChange={() => {}} />,
    );
    expect(screen.getByText("JavaScript")).toBeInTheDocument();
  });

  it("should show all languages when opened", async () => {
    const user = userEvent.setup();
    render(
      <LanguageSelector language="javascript" onChange={() => {}} />,
    );

    await user.click(screen.getByText("JavaScript"));

    // Check that all 11 languages are in the DOM when dropdown is open
    for (const lang of LANGUAGES) {
      const items = screen.getAllByText(lang.label);
      expect(items.length).toBeGreaterThanOrEqual(1);
    }
  });

  it("should call onChange when a language is selected from the dropdown", async () => {
    const onChange = vi.fn();
    const user = userEvent.setup();
    // Set initial language to the same one we'll click, so it appears in both trigger + dropdown
    render(
      <LanguageSelector language="typescript" onChange={onChange} />,
    );

    await user.click(screen.getByText("TypeScript"));

    // Now "TypeScript" appears twice: in trigger button and dropdown list
    // Click the SECOND one (the dropdown item)
    await user.click(screen.getAllByText("TypeScript")[1]);

    expect(onChange).toHaveBeenCalledWith("typescript");
  });

  it("should close the dropdown after selecting a language", async () => {
    const user = userEvent.setup();
    render(
      <LanguageSelector language="javascript" onChange={() => {}} />,
    );

    await user.click(screen.getByText("JavaScript"));

    // Dropdown is open - TypeScript should be visible next to the trigger
    expect(screen.getAllByText("TypeScript").length).toBeGreaterThanOrEqual(1);

    // Click TypeScript in the dropdown
    await user.click(screen.getAllByText("TypeScript")[1]);

    // After closing, TypeScript should no longer appear in the DOM
    // Use queryAllByText which returns [] instead of throwing
    expect(screen.queryAllByText("TypeScript")).toHaveLength(0);
  });

  it("should close the dropdown when clicking outside", async () => {
    const user = userEvent.setup();
    render(
      <div>
        <div data-testid="outside">Outside Area</div>
        <LanguageSelector language="typescript" onChange={() => {}} />
      </div>,
    );

    await user.click(screen.getByText("TypeScript"));

    // Dropdown is open - JavaScript should appear in trigger and dropdown
    expect(screen.getAllByText("JavaScript").length).toBeGreaterThanOrEqual(1);

    // Click outside the dropdown
    await user.click(screen.getByTestId("outside"));

    // After closing, only the trigger button text should remain
    // Use queryAllByText for non-throwing check
    expect(screen.queryAllByText("JavaScript")).toHaveLength(0);
  });

  it("should display the Code2 icon", () => {
    const { container } = render(
      <LanguageSelector language="javascript" onChange={() => {}} />,
    );
    expect(container.querySelector("svg")).toBeInTheDocument();
  });
});
