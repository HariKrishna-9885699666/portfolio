import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { ConnectionStatus } from "@/components/ConnectionStatus";

describe("ConnectionStatus", () => {
  it("should show connecting state with pulse animation", () => {
    render(<ConnectionStatus status="connecting" />);
    expect(screen.getByText("Connecting...")).toBeInTheDocument();
  });

  it("should show connected state", () => {
    render(<ConnectionStatus status="connected" />);
    expect(screen.getByText("Connected")).toBeInTheDocument();
  });

  it("should show disconnected state", () => {
    render(<ConnectionStatus status="disconnected" />);
    expect(screen.getByText("Disconnected")).toBeInTheDocument();
  });

  it("should show real-time sync message", () => {
    render(<ConnectionStatus status="connected" />);
    expect(
      screen.getByText("Changes are synced in real-time"),
    ).toBeInTheDocument();
  });

  it("should display the Monitor icon", () => {
    const { container } = render(<ConnectionStatus status="connected" />);
    // lucide-react Monitor icon renders as an SVG
    expect(container.querySelector("svg")).toBeInTheDocument();
  });
});
