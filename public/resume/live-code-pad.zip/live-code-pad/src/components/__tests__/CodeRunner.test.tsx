import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { CodeRunner } from "@/components/CodeRunner";

// The CodeRunner's getTemplateConfig logic determines which languages are supported.
// This tests the language support mapping without relying on Sandpack.

describe("CodeRunner language support", () => {
  const supportedLanguages = [
    { language: "javascript", label: "JavaScript" },
  ];

  const unsupportedLanguages = [
    { language: "python", label: "Python" },
    { language: "java", label: "Java" },
    { language: "go", label: "Go" },
    { language: "html", label: "HTML" },
  ];

  it.each(supportedLanguages)(
    "should show Run Code button for $label",
    ({ language }) => {
      render(<CodeRunner code="test code" language={language as any} />);
      // Use getAllByText since "Run Code" appears in both the button and placeholder text
      expect(screen.getAllByText("Run Code").length).toBeGreaterThan(0);
    },
  );

  it.each(unsupportedLanguages)(
    "should show unsupported message for $label",
    ({ language }) => {
      render(<CodeRunner code="test code" language={language as any} />);
      expect(
        screen.getByText("Code execution not supported for this language yet"),
      ).toBeInTheDocument();
    },
  );
});

describe("CodeRunner UI", () => {
  it("should show Run Code button in default state", () => {
    render(
      <CodeRunner code="console.log('hello')" language="javascript" />,
    );

    // The Run Code button should be visible (use getAllByText since it appears twice)
    const runCodeElements = screen.getAllByText("Run Code");
    expect(runCodeElements.length).toBeGreaterThan(0);
    // Verify at least one is a button
    expect(runCodeElements.some((el) => el.tagName === "BUTTON")).toBe(true);
    // The output panel should be visible with placeholder text
    // Note: text is split across child elements, so check individual fragments
    expect(screen.getByText("Click", { exact: false })).toBeInTheDocument();
    expect(screen.getByText("to execute", { exact: false })).toBeInTheDocument();
  });

  it("should display keyboard shortcut hint", () => {
    render(<CodeRunner code="test" language="javascript" />);
    // The hint is in the "Click Run Code to execute or press" text
    expect(screen.getByText(/or press/)).toBeInTheDocument();
  });

  it("should not show keyboard shortcut hint for unsupported languages", () => {
    render(<CodeRunner code="test" language={"python" as any} />);
    expect(screen.queryByText(/or press/)).not.toBeInTheDocument();
  });
});
