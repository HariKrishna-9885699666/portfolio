import { describe, it, expect, vi, beforeAll, afterEach, afterAll } from "vitest";
import { render, screen, fireEvent, act, waitFor } from "@testing-library/react";
import { CopyLinkButton } from "@/components/CopyLinkButton";

// Store original clipboard
const originalClipboard = navigator.clipboard;

describe("CopyLinkButton", () => {
  beforeAll(() => {
    // Mock clipboard API
    Object.defineProperty(navigator, "clipboard", {
      value: {
        writeText: vi.fn().mockResolvedValue(undefined),
      },
      configurable: true,
      writable: true,
    });
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  afterAll(() => {
    Object.defineProperty(navigator, "clipboard", {
      value: originalClipboard,
      configurable: true,
    });
  });

  it("should render with 'Copy Link' text", () => {
    render(<CopyLinkButton roomId="abc123xyz" />);
    expect(screen.getByRole("button", { name: /copy/i })).toBeInTheDocument();
    expect(screen.getByText("Copy Link")).toBeInTheDocument();
  });

  it("should show 'Copied!' after clicking", async () => {
    render(<CopyLinkButton roomId="abc123xyz" />);

    fireEvent.click(screen.getByText("Copy Link"));

    // Wait for the async clipboard operation and re-render
    await waitFor(() => {
      expect(screen.getByText("Copied!")).toBeInTheDocument();
    });

    expect(navigator.clipboard.writeText).toHaveBeenCalledWith(
      "http://localhost:3000/room/abc123xyz",
    );
  });

  it("should revert back to 'Copy Link' after 2 seconds", async () => {
    vi.useFakeTimers();
    render(<CopyLinkButton roomId="abc123xyz" />);

    // Use fireEvent + waitFor with fake timers
    fireEvent.click(screen.getByText("Copy Link"));

    // Let the promise resolve
    await vi.waitFor(() => {
      expect(screen.getByText("Copied!")).toBeInTheDocument();
    });

    // Advance time by 2 seconds
    act(() => {
      vi.advanceTimersByTime(2000);
    });

    expect(screen.getByText("Copy Link")).toBeInTheDocument();

    vi.useRealTimers();
  });

  it("should include the correct room URL in clipboard", async () => {
    render(<CopyLinkButton roomId="test12345" />);

    fireEvent.click(screen.getByText("Copy Link"));

    await waitFor(() => {
      expect(screen.getByText("Copied!")).toBeInTheDocument();
    });

    expect(navigator.clipboard.writeText).toHaveBeenCalledWith(
      "http://localhost:3000/room/test12345",
    );
  });

  it("should fall back to execCommand if clipboard API is unavailable", async () => {
    // Temporarily remove clipboard API
    Object.defineProperty(navigator, "clipboard", {
      value: undefined,
      configurable: true,
    });

    const execCommand = vi.fn().mockReturnValue(true);
    document.execCommand = execCommand;

    render(<CopyLinkButton roomId="abc123xyz" />);

    // Use fireEvent to click
    fireEvent.click(screen.getByText("Copy Link"));

    // The copy execCommand fires synchronously, so Copied should appear
    await waitFor(() => {
      expect(screen.getByText("Copied!")).toBeInTheDocument();
    });
    expect(execCommand).toHaveBeenCalledWith("copy");

    // Restore clipboard mock
    Object.defineProperty(navigator, "clipboard", {
      value: {
        writeText: vi.fn().mockResolvedValue(undefined),
      },
      configurable: true,
    });
  });
});
