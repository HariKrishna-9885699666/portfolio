import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { InterviewTimer } from "@/components/InterviewTimer";
import type { TimerDuration, InterviewStatus } from "@/types/editor";

describe("InterviewTimer", () => {
  const defaultProps = () => ({
    duration: null as TimerDuration | null,
    startedAt: null as number | null,
    status: "idle" as InterviewStatus,
    isInterviewer: true,
    onStart: vi.fn(),
    onStop: vi.fn(),
  });

  describe("idle state", () => {
    it("should show duration preset buttons for interviewer", () => {
      render(<InterviewTimer {...defaultProps()} />);
      expect(screen.getByText("30min")).toBeInTheDocument();
      expect(screen.getByText("60min")).toBeInTheDocument();
      expect(screen.getByText("90min")).toBeInTheDocument();
    });

    it("should show Start Timer button for interviewer", () => {
      render(<InterviewTimer {...defaultProps()} />);
      expect(screen.getByText("Start Timer")).toBeInTheDocument();
    });

    it("should select 30min by default", () => {
      render(<InterviewTimer {...defaultProps()} />);
      const btn30 = screen.getByText("30min");
      expect(btn30.className).toContain("indigo");
    });

    it("should call onStart when Start Timer is clicked", () => {
      const props = defaultProps();
      render(<InterviewTimer {...props} />);

      fireEvent.click(screen.getByText("Start Timer"));

      expect(props.onStart).toHaveBeenCalledWith(30);
    });

    it("should call onStart with selected duration when changed", () => {
      const props = defaultProps();
      render(<InterviewTimer {...props} />);

      fireEvent.click(screen.getByText("60min"));
      fireEvent.click(screen.getByText("Start Timer"));

      expect(props.onStart).toHaveBeenCalledWith(60);
    });

    it("should show 'Timer not started' for non-interviewer", () => {
      render(<InterviewTimer {...defaultProps()} isInterviewer={false} />);
      expect(screen.getByText("Timer not started")).toBeInTheDocument();
    });

    it("should not show controls for non-interviewer", () => {
      render(<InterviewTimer {...defaultProps()} isInterviewer={false} />);
      expect(screen.queryByText("Start Timer")).not.toBeInTheDocument();
      expect(screen.queryByText("30min")).not.toBeInTheDocument();
    });
  });

  describe("running state", () => {
    it("should display the timer countdown", () => {
      const startedAt = Date.now() - 60000; // 1 minute ago
      render(
        <InterviewTimer
          {...defaultProps()}
          duration={30}
          startedAt={startedAt}
          status="running"
        />,
      );
      expect(screen.getByText("29:00")).toBeInTheDocument();
    });

    it("should show Stop button for interviewer", () => {
      render(
        <InterviewTimer
          {...defaultProps()}
          duration={30}
          startedAt={Date.now()}
          status="running"
        />,
      );
      expect(screen.getByText("Stop")).toBeInTheDocument();
    });

    it("should call onStop when Stop is clicked", () => {
      const props = defaultProps();
      render(
        <InterviewTimer
          {...props}
          duration={30}
          startedAt={Date.now()}
          status="running"
        />,
      );

      fireEvent.click(screen.getByText("Stop"));

      expect(props.onStop).toHaveBeenCalledOnce();
    });

    it("should show warning style when under 5 minutes", () => {
      const startedAt = Date.now() - 25 * 60 * 1000; // 25 min ago
      render(
        <InterviewTimer
          {...defaultProps()}
          duration={30}
          startedAt={startedAt}
          status="running"
        />,
      );
      expect(screen.getByText(/05:00/)).toBeInTheDocument();
    });

    it("should show critical style when under 1 minute", () => {
      const startedAt = Date.now() - 29 * 60 * 1000; // 29 min ago
      render(
        <InterviewTimer
          {...defaultProps()}
          duration={30}
          startedAt={startedAt}
          status="running"
        />,
      );
      expect(screen.getByText(/01:00/)).toBeInTheDocument();
    });
  });

  describe("finished state", () => {
    it("should show TIME'S UP when timer expires", () => {
      const startedAt = Date.now() - 30 * 60 * 1000; // 30 min ago
      render(
        <InterviewTimer
          {...defaultProps()}
          duration={30}
          startedAt={startedAt}
          status="running"
        />,
      );
      expect(screen.getByText("TIME'S UP")).toBeInTheDocument();
    });

    it("should not show timer display when finished without running", () => {
      render(<InterviewTimer {...defaultProps()} status="finished" />);
      expect(screen.queryByText("TIME'S UP")).not.toBeInTheDocument();
      expect(screen.queryByText(/:/)).not.toBeInTheDocument();
    });
  });

  describe("disconnected interviewer", () => {
    it("should not show controls when not the interviewer", () => {
      render(
        <InterviewTimer
          {...defaultProps()}
          duration={30}
          startedAt={Date.now()}
          status="running"
          isInterviewer={false}
        />,
      );
      expect(screen.queryByText("Stop")).not.toBeInTheDocument();
      expect(screen.queryByText("Start Timer")).not.toBeInTheDocument();
    });

    it("should still show the timer countdown for non-interviewers", () => {
      const startedAt = Date.now() - 120000; // 2 minutes ago
      render(
        <InterviewTimer
          {...defaultProps()}
          duration={30}
          startedAt={startedAt}
          status="running"
          isInterviewer={false}
        />,
      );
      expect(screen.getByText("28:00")).toBeInTheDocument();
    });
  });
});
