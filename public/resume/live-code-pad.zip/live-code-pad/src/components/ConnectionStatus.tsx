"use client";

import { Monitor } from "lucide-react";

interface ConnectionStatusProps {
  status: "connecting" | "connected" | "disconnected";
}

export function ConnectionStatus({ status }: ConnectionStatusProps) {
  const config = {
    connecting: {
      color: "text-amber-400",
      bg: "bg-amber-400/10",
      dot: "bg-amber-400",
      label: "Connecting...",
    },
    connected: {
      color: "text-emerald-400",
      bg: "bg-emerald-400/10",
      dot: "bg-emerald-400",
      label: "Connected",
    },
    disconnected: {
      color: "text-red-400",
      bg: "bg-red-400/10",
      dot: "bg-red-400",
      label: "Disconnected",
    },
  }[status];

  return (
    <div className="flex items-center justify-between px-4 py-1.5 bg-[#1e1e1e] border-t border-[#333]">
      <div className="flex items-center gap-2">
        <Monitor className="w-3.5 h-3.5 text-gray-500" />
        <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium ${config.color} ${config.bg}`}>
          <span className={`w-1.5 h-1.5 rounded-full ${config.dot} ${status === "connecting" ? "animate-pulse" : ""}`} />
          {config.label}
        </div>
      </div>
      <div className="text-xs text-gray-500">
        Changes are synced in real-time
      </div>
    </div>
  );
}
