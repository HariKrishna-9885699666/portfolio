"use client";

import { useState, useCallback, useEffect, useRef } from "react";
import { FileText, X, Download } from "lucide-react";

interface InterviewNotesProps {
  isOpen: boolean;
  onClose: () => void;
  notes: string;
  onNotesChange: (notes: string) => void;
  isInterviewer: boolean;
  editorContent?: string;
}

export function InterviewNotes({
  isOpen,
  onClose,
  notes,
  onNotesChange,
  isInterviewer,
  editorContent,
}: InterviewNotesProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (isOpen && isInterviewer && textareaRef.current) {
      textareaRef.current.focus();
    }
  }, [isOpen, isInterviewer]);

  const handleExport = useCallback(() => {
    const timestamp = new Date().toISOString().split("T")[0];
    const header = `CodePad Interview Transcript - ${timestamp}\n${"=".repeat(50)}\n\n`;
    const notesSection = notes
      ? `## Interview Notes\n${notes}\n\n`
      : "";
    const codeSection = editorContent
      ? `## Code Content\n\n\`\`\`\n${editorContent}\n\`\`\`\n`
      : "";

    const content = `${header}${notesSection}${codeSection}`;
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `codepad-interview-${timestamp}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [notes, editorContent]);

  if (!isOpen) return null;

  return (
    <div className="w-80 h-full bg-[#1e1e1e] border-l border-[#3c3c3d] flex flex-col shrink-0">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-[#3c3c3d] bg-[#252526]">
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-indigo-400" />
          <span className="text-sm font-semibold text-gray-200">
            Interview Notes
          </span>
          {!isInterviewer && (
            <span className="text-[10px] uppercase tracking-wider text-gray-500 bg-[#2d2d2d] px-1.5 py-0.5 rounded">
              Interviewer only
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          {isInterviewer && (
            <button
              onClick={handleExport}
              className="p-1.5 rounded-md text-gray-400 hover:text-gray-200 hover:bg-[#2d2d2d] transition-colors"
              title="Export transcript"
            >
              <Download className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 rounded-md text-gray-400 hover:text-gray-200 hover:bg-[#2d2d2d] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        {isInterviewer ? (
          <textarea
            ref={textareaRef}
            value={notes}
            onChange={(e) => onNotesChange(e.target.value)}
            placeholder="Write your interview notes here...&#10;&#10;Use this space to:&#10;• Track candidate responses&#10;• Note key observations&#10;• Rate code quality&#10;• Record follow-up questions"
            className="w-full h-full bg-transparent text-sm text-gray-200 p-4 resize-none focus:outline-none font-mono leading-relaxed placeholder:text-gray-600"
            spellCheck
          />
        ) : (
          <div className="p-4 text-sm text-gray-500 text-center pt-8">
            <FileText className="w-8 h-8 mx-auto mb-3 text-gray-600" />
            <p>Notes are visible only to the interviewer.</p>
          </div>
        )}
      </div>
    </div>
  );
}
