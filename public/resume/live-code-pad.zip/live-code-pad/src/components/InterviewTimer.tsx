"use client";

import { useState, useEffect, useCallback } from "react";
import { Timer as TimerIcon, Play, Square, Clock } from "lucide-react";
import type { TimerDuration, InterviewStatus } from "@/types/editor";

interface InterviewTimerProps {
  duration: TimerDuration | null;
  startedAt: number | null;
  status: InterviewStatus;
  isInterviewer: boolean;
  onStart: (duration: TimerDuration) => void;
  onStop: () => void;
}

export function InterviewTimer({
  duration,
  startedAt,
  status,
  isInterviewer,
  onStart,
  onStop,
}: InterviewTimerProps) {
  const [remaining, setRemaining] = useState<number | null>(null);
  const [selectedDuration, setSelectedDuration] = useState<TimerDuration>(30);

  // Calculate remaining time every second
  useEffect(() => {
    if (status !== "running" || !startedAt || !duration) {
      setRemaining(null);
      return;
    }

    const updateRemaining = () => {
      const elapsed = Math.floor((Date.now() - startedAt) / 1000);
      const total = duration * 60;
      const left = total - elapsed;
      setRemaining(Math.max(0, left));
    };

    updateRemaining();
    const interval = setInterval(updateRemaining, 1000);
    return () => clearInterval(interval);
  }, [status, startedAt, duration]);

  const formatTime = (seconds: number): string => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  const isWarning = remaining !== null && remaining <= 300 && remaining > 60; // 5 min warning
  const isCritical = remaining !== null && remaining <= 60; // 1 min critical
  const isExpired = remaining === 0;

  return (
    <div className="flex items-center gap-3">
      {/* Timer display */}
      {(status === "running" || status === "finished") && remaining !== null ? (
        <div
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-sm font-mono font-bold transition-colors duration-300 ${
            isExpired
              ? "bg-red-500/20 text-red-400 border-red-500/30 animate-pulse"
              : isCritical
              ? "bg-red-500/15 text-red-400 border-red-500/25"
              : isWarning
              ? "bg-amber-500/15 text-amber-400 border-amber-500/25"
              : "bg-[#2d2d2d] text-gray-200 border-[#444]"
          }`}
        >
          <TimerIcon
            className={`w-3.5 h-3.5 ${
              isExpired || isCritical
                ? "text-red-400"
                : isWarning
                ? "text-amber-400"
                : "text-gray-400"
            }`}
          />
          <span>{isExpired ? "TIME'S UP" : formatTime(remaining)}</span>
          {isExpired && <span className="text-xs font-normal">⏰</span>}
        </div>
      ) : null}

      {/* Controls (interviewer only) */}
      {isInterviewer && (
        <div className="flex items-center gap-2">
          {status === "idle" && (
            <>
              <div className="flex items-center gap-1 bg-[#2d2d2d] rounded-lg border border-[#444] p-0.5">
                {([30, 60, 90] as TimerDuration[]).map((dur) => (
                  <button
                    key={dur}
                    onClick={() => setSelectedDuration(dur)}
                    className={`px-2 py-1 rounded-md text-xs font-medium transition-colors ${
                      selectedDuration === dur
                        ? "bg-indigo-500/20 text-indigo-400"
                        : "text-gray-400 hover:text-gray-200"
                    }`}
                  >
                    {dur}min
                  </button>
                ))}
              </div>
              <button
                onClick={() => onStart(selectedDuration)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 hover:bg-indigo-500/30 transition-colors text-sm font-medium"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Start Timer</span>
              </button>
            </>
          )}
          {status === "running" && (
            <button
              onClick={onStop}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30 transition-colors text-sm font-medium"
            >
              <Square className="w-3.5 h-3.5" />
              <span>Stop</span>
            </button>
          )}
        </div>
      )}

      {/* Show duration preset when timer is not running */}
      {status === "idle" && !isInterviewer && (
        <div className="flex items-center gap-1.5 text-xs text-gray-500">
          <Clock className="w-3 h-3" />
          <span>Timer not started</span>
        </div>
      )}
    </div>
  );
}
