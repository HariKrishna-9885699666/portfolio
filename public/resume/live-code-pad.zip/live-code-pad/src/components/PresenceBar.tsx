"use client";

import { useOthers, useSelf } from "@liveblocks/react";
import { Users } from "lucide-react";

export function PresenceBar() {
  const others = useOthers();
  const self = useSelf();
  const selfConnectionId = self?.connectionId;

  // Combine self with others for display
  const users = self
    ? [
        { connectionId: self.connectionId, id: self.id, info: self.info },
        ...others,
      ]
    : others;

  return (
    <div className="flex items-center gap-2">
      <Users className="w-4 h-4 text-gray-400" />
      <div className="flex items-center -space-x-1.5">
        {users.map((user) => (
          <div
            key={user.id}
            className="relative group"
          >
            <div
              className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white ring-2 ring-[#1e1e1e] transition-transform duration-200 hover:scale-110 hover:z-10 cursor-default"
              style={{ backgroundColor: (user.info?.color as string) ?? "#6366f1" }}
            >
              {(user.info?.name as string ?? "?").charAt(0).toUpperCase()}
            </div>
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 rounded-md bg-[#2d2d2d] text-xs text-gray-200 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none shadow-lg border border-[#444]">
              {user.info?.name as string ?? "Anonymous"}
              {user.connectionId === selfConnectionId && " (you)"}
            </div>
          </div>
        ))}
      </div>
      {users.length > 0 && (
        <span className="text-xs text-gray-400 ml-1">
          {users.length} {users.length === 1 ? "user" : "users"}
        </span>
      )}
    </div>
  );
}
