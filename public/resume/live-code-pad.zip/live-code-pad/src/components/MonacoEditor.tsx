"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Editor, { type OnMount, type BeforeMount } from "@monaco-editor/react";
import type { editor } from "monaco-editor";
import { useOthers } from "@liveblocks/react";
import { useYjs } from "@/providers/YjsProvider";
import type { SupportedLanguage } from "@/types/editor";
import { DEFAULT_CODE, getLanguageById } from "@/lib/monaco";

interface MonacoEditorProps {
  language: SupportedLanguage;
  tabId: string;
  readOnly?: boolean;
  onEditorMount?: (editor: editor.IStandaloneCodeEditor) => void;
  onContentChange?: (content: string) => void;
}

type Monaco = typeof import("monaco-editor");

function getTabYText(yDoc: import("yjs").Doc, tabId: string) {
  return yDoc.getText("tab-content-" + tabId);
}

export function MonacoEditor({
  language,
  tabId,
  readOnly = false,
  onEditorMount,
  onContentChange,
}: MonacoEditorProps) {
  const editorRef = useRef<editor.IStandaloneCodeEditor | null>(null);
  const monacoRef = useRef<Monaco | null>(null);
  const decorationIdsRef = useRef<string[]>([]);
  const styleRef = useRef<HTMLStyleElement | null>(null);
  const [editorValue, setEditorValue] = useState("");
  const defaultCodeInsertedMapRef = useRef<Map<string, boolean>>(new Map());
  const tabIdRef = useRef(tabId);
  tabIdRef.current = tabId;
  const { yDoc, bindEditor, disconnectEditor, connectionStatus } = useYjs();
  const others = useOthers();

  // Initialize editor content from Yjs when first connected.
  // Per-tab tracking ensures DEFAULT_CODE is only inserted once per tab per session.
  useEffect(() => {
    if (connectionStatus !== "connected") return;
    if (defaultCodeInsertedMapRef.current.get(tabId)) return;

    const yText = getTabYText(yDoc, tabId);

    // If Yjs already has content (from remote or a previous mount), mark as done
    if (yText.toString() !== "") {
      defaultCodeInsertedMapRef.current.set(tabId, true);
      return;
    }

    // Insert default code only on very first connect when yText is truly empty
    yText.insert(0, DEFAULT_CODE[language]);
    defaultCodeInsertedMapRef.current.set(tabId, true);
  }, [connectionStatus, language, yDoc, tabId]);

  // Sync yText → editorValue (controlled component).
  // When tabId changes, unobserve old yText and observe new one.
  useEffect(() => {
    const yText = getTabYText(yDoc, tabId);
    const sync = () => setEditorValue(yText.toString());
    sync();
    yText.observe(sync);
    return () => yText.unobserve(sync);
  }, [yDoc, tabId]);

  // Pass editor content changes to parent for export
  useEffect(() => {
    if (!onContentChange) return;
    onContentChange(editorValue);
  }, [editorValue, onContentChange]);

  // Re-bind the y-monaco binding when tabId changes
  useEffect(() => {
    const editor = editorRef.current;
    const monaco = monacoRef.current;
    if (!editor || !monaco) return;

    const yText = getTabYText(yDoc, tabId);
    disconnectEditor();
    bindEditor(editor, monaco, yText);
  }, [tabId, yDoc, bindEditor, disconnectEditor]);

  // Handle language changes on the editor model
  useEffect(() => {
    const editor = editorRef.current;
    const monaco = monacoRef.current;
    if (!editor || !monaco) return;

    const model = editor.getModel();
    if (model) {
      monaco.editor.setModelLanguage(model, getLanguageById(language).monacoLanguage);
    }
  }, [language]);

  // Remote cursor decorations - track other users' cursor positions
  useEffect(() => {
    const editor = editorRef.current;
    const monaco = monacoRef.current;
    if (!editor || !monaco) return;

    if (!styleRef.current) {
      styleRef.current = document.createElement("style");
      styleRef.current.id = "codepad-cursor-styles";
      document.head.appendChild(styleRef.current);
    }

    const cursorRules = others
      .filter((o) => o.presence?.cursor)
      .map((o) => {
        const userId = o.id ?? "";
        const color = (o.info?.color as string) ?? "#6366f1";
        return `
          .remote-cursor-${CSS.escape(userId)} {
            border-left: 2px solid ${color} !important;
            position: relative;
            width: 0 !important;
            box-sizing: border-box;
          }
        `;
      })
      .join("\n");

    styleRef.current.textContent = cursorRules;

    const decorations = others
      .filter((o) => o.presence?.cursor)
      .map((o) => {
        const presence = o.presence as Record<string, unknown> | undefined;
        const cursor = presence?.cursor as
          | { lineNumber: number; column: number }
          | undefined;
        if (!cursor) return null;
        const userId = o.id ?? "";
        const range = new monaco.Range(
          cursor.lineNumber,
          cursor.column,
          cursor.lineNumber,
          cursor.column + 1,
        );
        return {
          range,
          options: {
            className: `remote-cursor-${CSS.escape(userId)}`,
            hoverMessage: {
              value: `**${(o.info?.name as string) ?? "?"}** is editing`,
            },
          } as editor.IModelDecorationOptions,
        };
      });

    decorationIdsRef.current = editor.deltaDecorations(
      decorationIdsRef.current,
      decorations.filter(Boolean) as editor.IModelDeltaDecoration[],
    );
  }, [others]);

  // Clean up cursor styles on unmount
  useEffect(() => {
    return () => {
      if (styleRef.current) {
        styleRef.current.remove();
        styleRef.current = null;
      }
    };
  }, []);

  // Configure Monaco TypeScript defaults before the editor/model is created
  const handleBeforeMount: BeforeMount = useCallback((monaco) => {
    monaco.languages.typescript.javascriptDefaults.setCompilerOptions({
      jsx: monaco.languages.typescript.JsxEmit.ReactJSX,
    });
    monaco.languages.typescript.typescriptDefaults.setCompilerOptions({
      jsx: monaco.languages.typescript.JsxEmit.ReactJSX,
    });
  }, []);

  const handleEditorMount: OnMount = useCallback(
    (editorInstance, monaco) => {
      editorRef.current = editorInstance;
      monacoRef.current = monaco;

      // Bind Yjs to Monaco editor with the current tab's yText
      const yText = getTabYText(yDoc, tabId);
      bindEditor(editorInstance, monaco, yText);

      // Notify parent
      onEditorMount?.(editorInstance);

      editorInstance.focus();
    },
    [bindEditor, onEditorMount, yDoc, tabId],
  );

  return (
    <div className="relative flex-1 flex flex-col min-h-0">
      <div className="absolute inset-0">
        <Editor
          height="100%"
          language={getLanguageById(language).monacoLanguage}
          path={"file:///model-" + tabId + ".tsx"}
          theme="vs-dark"
          onChange={(val) => {
            if (val === undefined) return;
            setEditorValue(val);
          }}
          beforeMount={handleBeforeMount}
          onMount={handleEditorMount}
          options={{
            fontSize: 14,
            fontFamily:
              "'JetBrains Mono', 'Fira Code', 'Cascadia Code', 'Consolas', monospace",
            fontLigatures: true,
            minimap: { enabled: true, scale: 1 },
            scrollBeyondLastLine: false,
            wordWrap: "on",
            tabSize: 2,
            automaticLayout: true,
            cursorBlinking: "smooth",
            cursorSmoothCaretAnimation: "on",
            smoothScrolling: true,
            padding: { top: 16 },
            lineNumbers: "on",
            renderLineHighlight: "all",
            bracketPairColorization: { enabled: true },
            guides: { indentation: true, bracketPairs: true },
            suggestOnTriggerCharacters: true,
            quickSuggestions: true,
            formatOnPaste: true,
            readOnly,
            readOnlyMessage: readOnly
              ? { value: "Editor is in read-only mode (Interview Mode)" }
              : undefined,
          }}
          loading={
            <div className="flex-1 flex items-center justify-center text-gray-400">
              <div className="flex flex-col items-center gap-3">
                <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                <span className="text-sm">Loading editor...</span>
              </div>
            </div>
          }
        />
      </div>
    </div>
  );
}
