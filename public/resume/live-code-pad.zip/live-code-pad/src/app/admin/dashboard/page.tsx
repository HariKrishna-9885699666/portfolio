"use client";

import { useState, useCallback, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
  Plus,
  LogOut,
  Users,
  ExternalLink,
  Copy,
  Check,
  Clock,
  Shield,
  Trash2,
  Ban,
} from "lucide-react";
import { generateSessionRoomId } from "@/lib/room";
import type { SessionData } from "@/types/editor";

const SESSIONS_KEY = "codepad_admin_sessions";

function loadSessions(): SessionData[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(SESSIONS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveSessions(sessions: SessionData[]) {
  try {
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
  } catch {
    // localStorage may be full
  }
}

export default function AdminDashboardPage() {
  const router = useRouter();
  const [sessions, setSessions] = useState<SessionData[]>([]);
  const [candidateName, setCandidateName] = useState("");
  const [sessionId, setSessionId] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [revokeRoomId, setRevokeRoomId] = useState("");

  useEffect(() => {
    setSessions(loadSessions());
  }, []);

  const handleCreateSession = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault();
      const roomId = generateSessionRoomId(candidateName.trim() || "Candidate");
      const newSession: SessionData = {
        roomId,
        candidateName: candidateName.trim() || "Candidate",
        sessionId: sessionId.trim() || roomId,
        createdAt: Date.now(),
        accessGranted: false,
        isActive: false,
      };

      const updated = [newSession, ...sessions];
      saveSessions(updated);
      setSessions(updated);
      setCandidateName("");
      setSessionId("");

      // Navigate to session management
      router.push(`/admin/session/${roomId}`);
    },
    [candidateName, sessionId, sessions, router],
  );

  const handleDeleteSession = useCallback(
    (roomId: string) => {
      const updated = sessions.filter((s) => s.roomId !== roomId);
      saveSessions(updated);
      setSessions(updated);
    },
    [sessions],
  );

  const handleCopyUrl = useCallback(async (roomId: string) => {
    const url = `${window.location.origin}/room/${roomId}`;
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      const textarea = document.createElement("textarea");
      textarea.value = url;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
    }
    setCopiedId(roomId);
    setTimeout(() => setCopiedId(null), 2000);
  }, []);

  const handleLogout = useCallback(() => {
    sessionStorage.removeItem("admin_token");
    router.push("/admin");
  }, [router]);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-100 flex flex-col">
      {/* Header */}
      <nav className="flex items-center justify-between px-6 py-4 border-b border-[#1e1e1e]">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
            <Shield className="w-4 h-4 text-white" />
          </div>
          <div>
            <span className="text-lg font-bold text-white">Admin Dashboard</span>
            <span className="text-xs text-gray-500 ml-3">
              {sessions.length} session{sessions.length !== 1 ? "s" : ""}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <a
            href="/"
            className="text-sm text-gray-400 hover:text-white transition-colors"
          >
            Home
          </a>
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#2d2d2d] text-gray-300 border border-[#444] hover:bg-red-500/20 hover:text-red-400 hover:border-red-500/30 transition-colors text-sm"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </nav>

      <div className="flex-1 max-w-5xl w-full mx-auto px-6 py-8">
        {/* Create Session Form */}
        <div className="rounded-xl border border-[#1e1e1e] bg-[#0e0e0e] p-6 mb-8">
          <h2 className="text-lg font-semibold text-gray-200 mb-4 flex items-center gap-2">
            <Plus className="w-4 h-4 text-indigo-400" />
            Create New Session
          </h2>
          <form onSubmit={handleCreateSession} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-gray-500 mb-1.5 font-medium">
                  Candidate Name
                </label>
                <input
                  type="text"
                  value={candidateName}
                  onChange={(e) => setCandidateName(e.target.value)}
                  placeholder="e.g. John Doe"
                  required
                  className="w-full px-4 py-2.5 rounded-lg bg-[#1e1e1e] border border-[#333] text-gray-200 placeholder:text-gray-600 focus:border-indigo-500 focus:outline-none transition-colors"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-500 mb-1.5 font-medium">
                  Session Identifier
                </label>
                <input
                  type="text"
                  value={sessionId}
                  onChange={(e) => setSessionId(e.target.value)}
                  placeholder="Auto-generated if empty"
                  className="w-full px-4 py-2.5 rounded-lg bg-[#1e1e1e] border border-[#333] text-gray-200 placeholder:text-gray-600 focus:border-indigo-500 focus:outline-none transition-colors"
                />
              </div>
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={!candidateName.trim()}
                className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold text-sm hover:from-indigo-400 hover:to-purple-500 transition-all duration-300 shadow-lg shadow-indigo-500/25 hover:shadow-indigo-500/40 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Users className="w-4 h-4" />
                <span>Create Session</span>
              </button>
            </div>
          </form>
        </div>

        {/* Revoke orphaned session — type a room ID to revoke access for sessions deleted with old code */}
        <div className="rounded-xl border border-[#1e1e1e] bg-[#0e0e0e] p-4 mb-8">
          <h2 className="text-sm font-semibold text-gray-400 mb-3 flex items-center gap-2">
            <Ban className="w-4 h-4 text-red-400" />
            Revoke Session Access
          </h2>
          <div className="flex items-center gap-3">
            <input
              type="text"
              value={revokeRoomId}
              onChange={(e) => setRevokeRoomId(e.target.value)}
              placeholder="Paste room ID here... e.g. pp-uu-live-code-test-jf2bcv"
              className="flex-1 px-4 py-2.5 rounded-lg bg-[#1e1e1e] border border-[#333] text-gray-200 placeholder:text-gray-600 focus:border-red-500 focus:outline-none transition-colors text-sm font-mono"
            />
            <button
              onClick={() => {
                // Extract room ID: handle both raw IDs and full URLs like
                // http://localhost:3000/room/pp-uu-live-code-test-jf2bcv
                const raw = revokeRoomId.trim();
                // Extract room ID: handles raw IDs, full URLs, and URLs with trailing slash
                const match = raw.match(/([a-zA-Z0-9_-]+)$/);
                const id = match ? match[1] : raw;
                if (id) router.push(`/admin/session/${id}?action=delete`);
              }}
              disabled={!revokeRoomId.trim()}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold bg-red-500/15 text-red-400 border border-red-500/25 hover:bg-red-500/25 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Ban className="w-4 h-4" />
              <span>Revoke &amp; Delete</span>
            </button>
          </div>
          <p className="text-xs text-gray-600 mt-2">
            Use this to revoke access for sessions that were deleted before the fix.
            You can paste a full candidate URL or just the room ID.
          </p>
        </div>

        {/* Sessions List */}
        {sessions.length === 0 ? (
          <div className="text-center py-16">
            <Users className="w-12 h-12 text-gray-700 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-400 mb-1">
              No sessions yet
            </h3>
            <p className="text-sm text-gray-600">
              Create your first interview session above
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider px-1">
              Recent Sessions
            </h3>
            {sessions.map((session) => (
              <div
                key={session.roomId}
                className="rounded-xl border border-[#1e1e1e] bg-[#0e0e0e] p-4 hover:border-[#333] transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-600/20 flex items-center justify-center shrink-0">
                      <Users className="w-4 h-4 text-indigo-400" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-gray-200 truncate">
                          {session.candidateName}
                        </span>
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                            session.accessGranted
                              ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/25"
                              : "bg-amber-500/15 text-amber-400 border border-amber-500/25"
                          }`}
                        >
                          {session.accessGranted ? "Active" : "Pending"}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-gray-500 mt-0.5">
                        <span className="font-mono">
                          {session.sessionId}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(session.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleCopyUrl(session.roomId)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#2d2d2d] text-gray-300 border border-[#444] hover:bg-[#3d3d3d] transition-colors"
                      title="Copy candidate URL"
                    >
                      {copiedId === session.roomId ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>{copiedId === session.roomId ? "Copied!" : "Copy Link"}</span>
                    </button>

                    <button
                      onClick={() => router.push(`/admin/session/${session.roomId}`)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-indigo-500/15 text-indigo-400 border border-indigo-500/25 hover:bg-indigo-500/25 transition-colors"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Manage</span>
                    </button>

                    <button
                      onClick={() => {
                        // Navigate to session page with action=delete to revoke
                        // access in Yjs before removing from localStorage
                        router.push(`/admin/session/${session.roomId}?action=delete`);
                      }}
                      className="p-1.5 rounded-lg text-gray-500 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                      title="Delete session"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
