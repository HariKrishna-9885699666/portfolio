"use client";

import { useState, useCallback, useEffect, useRef } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { RoomProvider, useSelf, useOthers } from "@liveblocks/react";
import { YjsProvider, useYjs } from "@/providers/YjsProvider";
import { ChatPanel } from "@/components/ChatPanel";
import { MonacoEditor } from "@/components/MonacoEditor";
import type { SupportedLanguage, ChatMessage, AccessEvent } from "@/types/editor";
import {
  Shield,
  Users,
  ToggleLeft,
  ToggleRight,
  ArrowLeft,
  Clock,
  Wifi,
  WifiOff,
  Copy,
  Check,
  MessageSquare,
  Monitor,
  Square,
} from "lucide-react";
import { nanoid } from "nanoid";
import { TabBar } from "@/components/TabBar";
import type { TabData } from "@/types/editor";

function AdminSessionContent({ roomId }: { roomId: string }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { yDoc, connectionStatus } = useYjs();
  const self = useSelf();
  const others = useOthers();
  const [accessGranted, setAccessGranted] = useState(false);
  const [candidateName, setCandidateName] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [copied, setCopied] = useState(false);
  const [activePanel, setActivePanel] = useState<"editor" | "chat">("editor");
  const [language, setLanguage] = useState<SupportedLanguage>("javascript");
  const [tabs, setTabs] = useState<TabData[]>([]);
  const [activeTabId, setActiveTabId] = useState<string>("default");
  const codeRef = useRef("");
  const nameSyncedRef = useRef(false);
  const langSyncedRef = useRef(false);
  const tabInitRef = useRef(false);

  // Handle ?action=delete: revoke access, remove from localStorage, redirect to dashboard
  // Waits for Yjs to connect before making changes to ensure reliable propagation
  const deleteActionFired = useRef(false);
  const deleteTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (searchParams.get("action") !== "delete") return;
    if (deleteActionFired.current) return;

    // If Yjs doesn't connect within 8 seconds, proceed anyway (changes queue locally)
    if (connectionStatus !== "connected") {
      if (!deleteTimeoutRef.current) {
        deleteTimeoutRef.current = setTimeout(() => {
          deleteActionFired.current = true;
          doDelete();
        }, 8000);
      }
      return;
    }

    deleteActionFired.current = true;
    if (deleteTimeoutRef.current) {
      clearTimeout(deleteTimeoutRef.current);
      deleteTimeoutRef.current = null;
    }

    doDelete();

    function doDelete() {
      // Revoke access in Yjs (this propagates to the candidate immediately)
      const accessMap = yDoc.getMap("access-settings");
      accessMap.set("accessGranted", false);
      accessMap.set("lastAction", "revoked");

      // Record access event
      const events = yDoc.getArray<AccessEvent>("access-events");
      events.push([{ type: "revoked", timestamp: Date.now() }]);

      // Remove from localStorage
      try {
        const raw = localStorage.getItem("codepad_admin_sessions");
        if (raw) {
          const sessions = JSON.parse(raw) as Array<{ roomId: string }>;
          const updated = sessions.filter((s) => s.roomId !== roomId);
          localStorage.setItem("codepad_admin_sessions", JSON.stringify(updated));
        }
      } catch {
        // localStorage unavailable or parse failed
      }

      // Give Yjs a moment to propagate, then redirect to dashboard
      setTimeout(() => {
        router.push("/admin/dashboard");
      }, 1000);
    }
  }, [searchParams, yDoc, roomId, router, connectionStatus]);

  // Initialize default tab if tabs array is empty
  useEffect(() => {
    if (connectionStatus !== "connected") return;
    if (tabInitRef.current) return;
    tabInitRef.current = true;

    const tabsArray = yDoc.getArray<TabData>("tabs");
    if (tabsArray.length === 0) {
      const defaultTab: TabData = { id: "default", name: "Tab 1", createdAt: Date.now() };
      tabsArray.push([defaultTab]);

      // Set default tab as active
      const activeTabMap = yDoc.getMap("activeTab");
      activeTabMap.set("id", "default");

      // Migrate any existing content from old "monaco" yText
      const oldYText = yDoc.getText("monaco");
      if (oldYText.toString()) {
        const newYText = yDoc.getText("tab-content-default");
        newYText.insert(0, oldYText.toString());
        oldYText.delete(0, oldYText.length);
      }
    } else {
      // Tabs already exist in Yjs — just make sure active tab is set
      const activeTabMap = yDoc.getMap("activeTab");
      if (!activeTabMap.get("id")) {
        activeTabMap.set("id", tabsArray.get(0)!.id);
      }
    }
  }, [connectionStatus, yDoc]);

  // Sync tabs from Yjs
  useEffect(() => {
    const tabsArray = yDoc.getArray<TabData>("tabs");
    const onChange = () => {
      setTabs(tabsArray.toArray());
    };
    tabsArray.observe(onChange);
    onChange();
    return () => tabsArray.unobserve(onChange);
  }, [yDoc]);

  // Sync active tab from Yjs
  useEffect(() => {
    const activeTabMap = yDoc.getMap("activeTab");
    const onChange = () => {
      const id = activeTabMap.get("id") as string | undefined;
      if (id) {
        setActiveTabId(id);
      }
    };
    activeTabMap.observeDeep(onChange);
    onChange();
    return () => activeTabMap.unobserveDeep(onChange);
  }, [yDoc]);

  const handleTabSelect = useCallback(
    (tabId: string) => {
      const activeTabMap = yDoc.getMap("activeTab");
      activeTabMap.set("id", tabId);
    },
    [yDoc],
  );

  // Sync access settings from Yjs — default to false (no access until admin grants)
  useEffect(() => {
    const accessMap = yDoc.getMap("access-settings");
    const onChange = () => {
      setAccessGranted((accessMap.get("accessGranted") as boolean) ?? false);
    };
    accessMap.observeDeep(onChange);
    onChange();
    return () => accessMap.unobserveDeep(onChange);
  }, [yDoc]);

  // Sync candidate name and language from Yjs interview map
  // Also write candidate name from admin's localStorage to Yjs on first mount
  useEffect(() => {
    const interviewMap = yDoc.getMap("interview");

    // Sync candidate name from localStorage sessions into Yjs on first mount
    if (!nameSyncedRef.current) {
      nameSyncedRef.current = true;
      try {
        const raw = localStorage.getItem("codepad_admin_sessions");
        if (raw) {
          const sessions = JSON.parse(raw) as Array<{ roomId: string; candidateName: string }>;
          const session = sessions.find((s) => s.roomId === roomId);
          if (session?.candidateName) {
            // Only set if Yjs doesn't already have a value
            if (!interviewMap.get("candidateName")) {
              interviewMap.set("candidateName", session.candidateName);
            }
          }
        }
      } catch {
        // localStorage unavailable or parse failed
      }
    }

    // Sync language preference from Yjs (so admin sees correct syntax highlighting)
    if (!langSyncedRef.current) {
      langSyncedRef.current = true;
      const yLang = interviewMap.get("language") as SupportedLanguage | undefined;
      if (yLang) {
        setLanguage(yLang);
      }
    }

    const onChange = () => {
      setCandidateName(
        (interviewMap.get("candidateName") as string) ?? "",
      );
      const yLang = interviewMap.get("language") as SupportedLanguage | undefined;
      if (yLang) {
        setLanguage(yLang);
      }
    };
    interviewMap.observeDeep(onChange);
    onChange();
    return () => interviewMap.unobserveDeep(onChange);
  }, [yDoc, roomId]);

  // Sync chat messages from Yjs
  useEffect(() => {
    const chatArray = yDoc.getArray<ChatMessage>("chat-messages");
    const onChange = () => {
      setChatMessages(chatArray.toArray());
    };
    chatArray.observe(onChange);
    onChange();
    return () => chatArray.unobserve(onChange);
  }, [yDoc]);

  // Send chat message
  const handleSendMessage = useCallback(
    (text: string) => {
      const chatArray = yDoc.getArray<ChatMessage>("chat-messages");
      const message: ChatMessage = {
        id: nanoid(8),
        senderId: "admin",
        senderName: "Admin",
        text,
        timestamp: Date.now(),
      };
      chatArray.push([message]);
    },
    [yDoc],
  );

  // Toggle access and record event
  const handleToggleAccess = useCallback(() => {
    const accessMap = yDoc.getMap("access-settings");
    const newStatus = !accessGranted;
    accessMap.set("accessGranted", newStatus);
    accessMap.set("lastAction", newStatus ? "granted" : "revoked");
    if (newStatus) {
      accessMap.set("everGranted", true);
    }
    // Record access event
    const events = yDoc.getArray<AccessEvent>("access-events");
    events.push([{ type: newStatus ? "granted" : "revoked", timestamp: Date.now() }]);
  }, [yDoc, accessGranted]);

  // End session — sets interview status to "finished" which triggers SessionCompleteView on the candidate side
  const handleEndSession = useCallback(() => {
    const interviewMap = yDoc.getMap("interview");
    interviewMap.set("status", "finished");
    interviewMap.set("isReadOnly", true);
    // Record timer event as "stop" for consistency
    const events = yDoc.getArray("timer-events");
    events.push([{ type: "stop", timestamp: Date.now() }]);
  }, [yDoc]);

  // Copy candidate URL
  const handleCopyUrl = useCallback(async () => {
    const url = `${window.location.origin}/room/${roomId}`;
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      const textarea = document.createElement("textarea");
      textarea.value = url;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [roomId]);

  // Count non-admin participants (candidates)
  const participants = others.filter((o) => o.id !== "admin-user");
  const candidateOnline = participants.length > 0;

  return (
    <div className="flex flex-col h-screen bg-[#1e1e1e]">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-2 bg-[#252526] border-b border-[#3c3c3d] shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={() => router.push("/admin/dashboard")}
            className="p-1.5 rounded-md text-gray-400 hover:text-gray-200 hover:bg-[#2d2d2d] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
            <Shield className="w-3.5 h-3.5 text-white" />
          </div>
          <div>
            <span className="text-sm font-semibold text-gray-200">
              Session: {candidateName || "Unnamed"}
            </span>
            <span className="text-xs text-gray-500 ml-2 font-mono">
              {roomId}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Candidate online status */}
          <div
            className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium ${
              candidateOnline
                ? "bg-emerald-400/10 text-emerald-400"
                : "bg-gray-500/10 text-gray-500"
            }`}
          >
            {candidateOnline ? (
              <Wifi className="w-3 h-3" />
            ) : (
              <WifiOff className="w-3 h-3" />
            )}
            <span>
              {candidateOnline
                ? `${participants.length} candidate${participants.length !== 1 ? "s" : ""} online`
                : "Candidate offline"}
            </span>
          </div>

          {/* Connection status */}
          <div
            className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium ${
              connectionStatus === "connected"
                ? "bg-emerald-400/10 text-emerald-400"
                : connectionStatus === "disconnected"
                  ? "bg-red-400/10 text-red-400"
                  : "bg-amber-400/10 text-amber-400"
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                connectionStatus === "connected"
                  ? "bg-emerald-400"
                  : connectionStatus === "disconnected"
                    ? "bg-red-400"
                    : "bg-amber-400 animate-pulse"
              }`}
            />
            <span>
              {connectionStatus === "connected"
                ? "Live"
                : connectionStatus === "disconnected"
                  ? "Offline"
                  : "Connecting"}
            </span>
          </div>

          <button
            onClick={handleCopyUrl}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              copied
                ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                : "bg-[#2d2d2d] text-gray-300 border border-[#444] hover:bg-[#3d3d3d]"
            }`}
          >
            {copied ? (
              <Check className="w-3.5 h-3.5" />
            ) : (
              <Copy className="w-3.5 h-3.5" />
            )}
            <span>{copied ? "Copied!" : "Share Link"}</span>
          </button>
        </div>
      </header>

      {/* Control bar */}
      <div className="flex items-center gap-3 px-4 py-2 bg-[#1e1e1e] border-b border-[#3c3c3d] shrink-0">
        <div className="flex items-center gap-2">
          <Users className="w-3.5 h-3.5 text-gray-500" />
          <span className="text-xs text-gray-400">
            {candidateName || "Candidate"}
          </span>
        </div>

        <div className="h-3 w-px bg-[#3c3c3d]" />

        {/* Access control toggle */}
        <button
          onClick={handleToggleAccess}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
            accessGranted
              ? "bg-emerald-500/15 text-emerald-400 border-emerald-500/25 hover:bg-emerald-500/25"
              : "bg-amber-500/15 text-amber-400 border-amber-500/25 hover:bg-amber-500/25"
          }`}
        >
          {accessGranted ? (
            <ToggleRight className="w-3.5 h-3.5" />
          ) : (
            <ToggleLeft className="w-3.5 h-3.5" />
          )}
          <span>
            {accessGranted ? "Access Granted" : "Access Revoked"}
          </span>
        </button>

        {candidateOnline && (
          <>
            <div className="h-3 w-px bg-[#3c3c3d]" />
            <span className="flex items-center gap-1 text-xs text-emerald-400">
              <Monitor className="w-3 h-3" />
              <span>Active</span>
            </span>
          </>
        )}

        <div className="flex-1" />

        {/* Panel switcher */}
        <div className="flex items-center gap-1 bg-[#2d2d2d] rounded-lg border border-[#444] p-0.5">
          <button
            onClick={() => setActivePanel("editor")}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              activePanel === "editor"
                ? "bg-indigo-500/20 text-indigo-400"
                : "text-gray-400 hover:text-gray-200"
            }`}
          >
            <Monitor className="w-3.5 h-3.5 inline-block mr-1.5" />
            Editor
          </button>
          <button
            onClick={() => setActivePanel("chat")}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              activePanel === "chat"
                ? "bg-indigo-500/20 text-indigo-400"
                : "text-gray-400 hover:text-gray-200"
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 inline-block mr-1.5" />
            Chat
            {chatMessages.length > 0 && (
              <span className="ml-1.5 px-1.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 text-[10px]">
                {chatMessages.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Code tab bar (read-only view for admin) */}
      {activePanel === "editor" && tabs.length > 0 && (
        <TabBar
          tabs={tabs}
          activeTabId={activeTabId}
          mode="view"
          onTabSelect={handleTabSelect}
          onTabCreate={() => {}}
          onTabDelete={() => {}}
        />
      )}

      {/* Content area */}
      <div className="flex flex-row flex-1 min-h-0">
        {/* Editor panel */}
        <div className="flex flex-col flex-1 min-w-0">
          {activePanel === "editor" ? (
            <div className="flex-1 flex flex-col min-h-0">
              <div className="px-4 py-1.5 bg-[#252526] border-b border-[#333] shrink-0">
                <span className="text-xs text-gray-500">
                  Live editor view {!candidateOnline ? "(candidate offline)" : ""}
                </span>
              </div>
              <div className="flex-1 min-h-0 flex flex-col">
                <MonacoEditor
                  language={language}
                  tabId={activeTabId}
                  readOnly={true}
                />
              </div>
            </div>
          ) : (
            /* Chat panel */
            <ChatPanel
              messages={chatMessages}
              onSendMessage={handleSendMessage}
              disabled={false}
              placeholder="Send a message to the candidate..."
            />
          )}
        </div>

        {/* Right info panel */}
        <div className="w-72 border-l border-[#333] flex flex-col bg-[#1e1e1e] shrink-0">
          {/* Session info */}
          <div className="p-4 border-b border-[#333]">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Session Info
            </h3>

            <div className="space-y-3">
              <div>
                <span className="text-[10px] text-gray-600 uppercase tracking-wider">Candidate</span>
                <p className="text-sm text-gray-200 mt-0.5">
                  {candidateName || "-"}
                </p>
              </div>

              <div>
                <span className="text-[10px] text-gray-600 uppercase tracking-wider">Session ID</span>
                <p className="text-sm text-gray-200 mt-0.5 font-mono text-xs">
                  {roomId}
                </p>
              </div>

              <div>
                <span className="text-[10px] text-gray-600 uppercase tracking-wider">Connection</span>
                <div className="flex items-center gap-2 mt-0.5">
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                      connectionStatus === "connected"
                        ? "bg-emerald-500/15 text-emerald-400"
                        : connectionStatus === "disconnected"
                          ? "bg-red-500/15 text-red-400"
                          : "bg-amber-500/15 text-amber-400"
                    }`}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        connectionStatus === "connected"
                          ? "bg-emerald-400"
                          : connectionStatus === "disconnected"
                            ? "bg-red-400"
                            : "bg-amber-400 animate-pulse"
                      }`}
                    />
                    {connectionStatus === "connected"
                      ? "Connected"
                      : connectionStatus === "disconnected"
                        ? "Disconnected"
                        : "Connecting"}
                  </span>
                </div>
              </div>

              <div>
                <span className="text-[10px] text-gray-600 uppercase tracking-wider">Access</span>
                <div className="flex items-center gap-2 mt-0.5">
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                      accessGranted
                        ? "bg-emerald-500/15 text-emerald-400"
                        : "bg-amber-500/15 text-amber-400"
                    }`}
                  >
                    {accessGranted ? "Granted" : "Revoked"}
                  </span>
                </div>
              </div>

              <div>
                <span className="text-[10px] text-gray-600 uppercase tracking-wider">Candidate Status</span>
                <div className="flex items-center gap-2 mt-0.5">
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                      candidateOnline
                        ? "bg-emerald-500/15 text-emerald-400"
                        : "bg-gray-500/15 text-gray-400"
                    }`}
                  >
                    {candidateOnline ? (
                      <Wifi className="w-3 h-3" />
                    ) : (
                      <WifiOff className="w-3 h-3" />
                    )}
                    {candidateOnline ? "Online" : "Offline"}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Participants list */}
          <div className="p-4 border-b border-[#333]">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Participants
            </h3>
            <div className="space-y-2">
              {/* Admin (self) */}
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-indigo-500 flex items-center justify-center text-[10px] font-bold text-white shrink-0">
                  A
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-gray-200 truncate">
                      Admin (you)
                    </span>
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  </div>
                </div>
              </div>

              {/* Candidates — show name from Yjs, not random Liveblocks info.name */}
              {participants.length === 0 ? (
                <div className="text-xs text-gray-500 italic">
                  No candidate connected yet
                </div>
              ) : (
                participants.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center gap-2"
                  >
                    <div
                      className="w-6 h-6 rounded-full bg-indigo-500 flex items-center justify-center text-[10px] font-bold text-white shrink-0"
                    >
                      {(candidateName || "C").charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs text-gray-200 truncate">
                          {candidateName || "Candidate"}
                        </span>
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="p-4 space-y-3">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Actions
            </h3>
            <button
              onClick={handleToggleAccess}
              className={`w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all duration-150 active:scale-[0.97] ${
                accessGranted
                  ? "bg-amber-500/15 text-amber-400 border border-amber-500/25 hover:bg-amber-500/25"
                  : "bg-emerald-500/15 text-emerald-400 border border-emerald-500/25 hover:bg-emerald-500/25"
              }`}
            >
              {accessGranted ? (
                <ToggleLeft className="w-4 h-4" />
              ) : (
                <ToggleRight className="w-4 h-4" />
              )}
              <span>
                {accessGranted ? "Revoke Access" : "Grant Access"}
              </span>
            </button>

            {/* End Session button */}
            <button
              onClick={handleEndSession}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold transition-all duration-150 active:scale-[0.97] bg-red-500/15 text-red-400 border border-red-500/25 hover:bg-red-500/25"
            >
              <Square className="w-4 h-4" />
              <span>End Session</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AdminSessionPage() {
  const params = useParams();
  const roomId = params.roomId as string;

  // Get admin token from sessionStorage
  const adminToken =
    typeof window !== "undefined"
      ? sessionStorage.getItem("admin_token") ?? ""
      : "";

  return (
    <RoomProvider
      id={roomId}
      initialPresence={{
        name: "Admin",
        color: "#6366f1",
        cursor: null,
      }}
    >
      <YjsProvider>
        <AdminSessionContent roomId={roomId} />
      </YjsProvider>
    </RoomProvider>
  );
}
