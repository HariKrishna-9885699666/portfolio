import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { LiveblocksProvider } from "@/providers/LiveblocksProvider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "CodePad - Collaborative Code Editor",
  description:
    "A lightweight, real-time collaborative code editor. Share a link and start coding together — no account required.",
  openGraph: {
    title: "CodePad - Collaborative Code Editor",
    description:
      "Real-time collaborative code editor for technical interviews, pair programming, and coding discussions.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${geistSans.variable} ${geistMono.variable}`}>
      <body className="min-h-screen bg-[#0a0a0a] antialiased" suppressHydrationWarning>
        <LiveblocksProvider>{children}</LiveblocksProvider>
      </body>
    </html>
  );
}
