import { notFound } from "next/navigation";
import { Editor } from "@/components/Editor";

interface RoomPageProps {
  params: Promise<{ roomId: string }>;
}

export default async function RoomPage({ params }: RoomPageProps) {
  const { roomId } = await params;

  // Validate room ID format: legacy 9-char nanoid or new slug format (alphanumeric, digits, hyphens)
  if (!/^[a-zA-Z0-9_-]{9}$/.test(roomId) && !/^[a-zA-Z0-9-]{10,}$/.test(roomId)) {
    notFound();
  }

  return <Editor roomId={roomId} />;
}
