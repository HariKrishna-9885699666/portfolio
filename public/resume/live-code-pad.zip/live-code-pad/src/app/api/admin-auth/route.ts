import { NextRequest, NextResponse } from "next/server";
import { nanoid } from "nanoid";

// In-memory store of valid admin tokens → issued timestamp
// Tokens expire after 24 hours
const validTokens = new Map<string, number>();
const TOKEN_TTL_MS = 24 * 60 * 60 * 1000;

// Clean up expired tokens periodically
setInterval(() => {
  const now = Date.now();
  for (const [token, issuedAt] of validTokens) {
    if (now - issuedAt > TOKEN_TTL_MS) {
      validTokens.delete(token);
    }
  }
}, 60 * 60 * 1000); // Cleanup every hour

export function verifyToken(token: string | null): boolean {
  if (!token) return false;
  const issuedAt = validTokens.get(token);
  if (!issuedAt) return false;
  if (Date.now() - issuedAt > TOKEN_TTL_MS) {
    validTokens.delete(token);
    return false;
  }
  return true;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { password } = body;

    const adminPassword = process.env.ADMIN_PASSWORD || "admin";

    if (!password || password !== adminPassword) {
      return NextResponse.json(
        { error: "Invalid password" },
        { status: 401 },
      );
    }

    // Generate an admin token and store it server-side
    const token = nanoid(32);
    validTokens.set(token, Date.now());

    return NextResponse.json({
      success: true,
      token,
      name: "Admin",
    });
  } catch (error) {
    console.error("Admin auth error:", error);
    return NextResponse.json(
      { error: "Authentication failed" },
      { status: 500 },
    );
  }
}
