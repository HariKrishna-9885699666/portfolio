import { Liveblocks } from "@liveblocks/node";
import { NextRequest } from "next/server";
import { generateUserName, generateUserColor, generateUserId } from "@/lib/room";
import { verifyToken } from "../admin-auth/route";

const liveblocks = new Liveblocks({
  secret: process.env.LIVEBLOCKS_SECRET_KEY!,
});

export async function POST(request: NextRequest) {
  try {
    // Parse query params for admin token
    const url = new URL(request.url);
    const adminToken = url.searchParams.get("adminToken");

    const body = await request.json();
    const { room } = body;

    if (!room || typeof room !== "string") {
      return new Response(JSON.stringify({ error: "Room ID is required" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    const isAdmin = verifyToken(adminToken);

    if (isAdmin) {
      // Admin user — fixed identity for consistency
      const session = liveblocks.prepareSession("admin-user", {
        userInfo: {
          name: "Admin",
          color: "#6366f1",
        },
      });
      session.allow(room, session.FULL_ACCESS);
      const { body: authBody, status } = await session.authorize();
      return new Response(authBody, { status });
    }

    // Verify room ID format for non-admin users
    // Supports: legacy 9-char nanoid or new slug format (alphanumeric + hyphens, min 10 chars)
    if (!/^[a-zA-Z0-9_-]{9}$/.test(room) && !/^[a-zA-Z0-9-]{10,}$/.test(room)) {
      return new Response(JSON.stringify({ error: "Invalid room ID format" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    const userId = generateUserId();
    const userName = generateUserName();
    const userColor = generateUserColor();

    const session = liveblocks.prepareSession(userId, {
      userInfo: {
        name: userName,
        color: userColor,
      },
    });

    session.allow(room, session.FULL_ACCESS);

    const { body: authBody, status } = await session.authorize();
    return new Response(authBody, { status });
  } catch (error) {
    console.error("Liveblocks auth error:", error);
    return new Response(
      JSON.stringify({ error: "Authentication failed" }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      }
    );
  }
}
