export interface User {
  id: string;
  name: string;
  color: string;
}

export interface CursorPosition {
  lineNumber: number;
  column: number;
}

export interface UserPresence {
  name: string;
  color: string;
  cursor: CursorPosition | null;
  isOnline: boolean;
  lastActivity: number;
  // Liveblocks requires index signature for JsonObject compatibility
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any;
}

// User metadata type for Liveblocks auth
export interface UserMeta {
  info: {
    name: string;
    color: string;
  };
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any;
}

export type SupportedLanguage =
  | "javascript"
  | "typescript";

export interface LanguageOption {
  id: SupportedLanguage;
  label: string;
  monacoLanguage: string;
}

// Interview Mode types
export type TimerDuration = 30 | 60 | 90;
export type InterviewStatus = "idle" | "running" | "finished";

export interface InterviewSettings {
  candidateName: string;
  interviewerId: string | null;
  isReadOnly: boolean;
  timerDuration: TimerDuration | null;
  timerStartedAt: number | null;
  status: InterviewStatus;
}

export const DEFAULT_INTERVIEW_SETTINGS: InterviewSettings = {
  candidateName: "",
  interviewerId: null,
  isReadOnly: false,
  timerDuration: null,
  timerStartedAt: null,
  status: "idle",
};

// Chat types
export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: number;
}

// Session management types
export interface SessionData {
  roomId: string;
  candidateName: string;
  sessionId: string;
  createdAt: number;
  accessGranted: boolean;
  isActive: boolean;
}

export type AccessStatus = "granted" | "revoked" | "pending";

// Execution history types
export interface LogEntry {
  id: number;
  type: "log" | "warn" | "error" | "info" | "result";
  message: string;
  timestamp: number;
}

export interface ExecutionRecord {
  id: string;
  timestamp: number;
  code: string;
  output: LogEntry[];
  status: "done" | "error";
}

// Tab types
export interface TabData {
  id: string;
  name: string;
  createdAt: number;
}

export function createTab(id: string, name: string): TabData {
  return { id, name, createdAt: Date.now() };
}

// Recording event types
export interface TimerEvent {
  type: "start" | "stop" | "expired";
  timestamp: number;
  duration?: TimerDuration;
}

export interface AccessEvent {
  type: "granted" | "revoked";
  timestamp: number;
}
