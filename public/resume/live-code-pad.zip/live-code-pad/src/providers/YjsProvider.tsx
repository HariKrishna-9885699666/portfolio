"use client";

import { createContext, useContext, useEffect, useRef, useState, useCallback } from "react";
import { useRoom } from "@liveblocks/react";
import * as Y from "yjs";
import { LiveblocksYjsProvider } from "@liveblocks/yjs";
import type { editor } from "monaco-editor";
import type { MonacoBinding } from "y-monaco";

// Dynamic import for MonacoBinding to avoid SSR "window is not defined" error
async function getMonacoBinding(): Promise<typeof MonacoBinding> {
  const mod = await import("y-monaco");
  return mod.MonacoBinding;
}

interface YjsContextValue {
  yDoc: Y.Doc;
  provider: LiveblocksYjsProvider;
  bindEditor: (
    editorInstance: editor.IStandaloneCodeEditor,
    monaco: typeof import("monaco-editor"),
    yText?: Y.Text,
  ) => void;
  disconnectEditor: () => void;
  connectionStatus: "connecting" | "connected" | "disconnected";
  connectionError: string | null;
}

const YjsContext = createContext<YjsContextValue | null>(null);

export function YjsProvider({ children }: { children: React.ReactNode }) {
  const room = useRoom();
  const [ready, setReady] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<
    "connecting" | "connected" | "disconnected"
  >("connecting");
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const yDocRef = useRef<Y.Doc | null>(null);
  const providerRef = useRef<LiveblocksYjsProvider | null>(null);
  const bindingRef = useRef<{ destroy: () => void } | null>(null);
  const genRef = useRef(0); // Incremented on every effect cycle — invalidates stale async callbacks

  useEffect(() => {
    if (!room) return;

    setConnectionError(null);
    genRef.current += 1;

    const yDoc = new Y.Doc();
    yDocRef.current = yDoc;

    const provider = new LiveblocksYjsProvider(room as any, yDoc);
    providerRef.current = provider;

    setConnectionStatus("connecting");

    // Connection timeout — if still connecting after 15s, show error
    const timeoutId = setTimeout(() => {
      setConnectionStatus("disconnected");
      setConnectionError(
        "Could not connect to collaboration server. Check your Liveblocks API key",
      );
    }, 15000);

    const handleSync = (synced: boolean) => {
      if (synced) {
        clearTimeout(timeoutId);
        setConnectionStatus("connected");
        setConnectionError(null);
      }
    };
    const handleStatus = (status: string) => {
      // LiveblocksYjsProvider emits status as a string: "synchronized" / "synchronizing" / "loading"
      if (status === "synchronized") {
        clearTimeout(timeoutId);
        setConnectionStatus("connected");
        setConnectionError(null);
      } else if (status === "synchronizing" || status === "loading") {
        setConnectionStatus("connecting");
      } else if (status === "disconnected") {
        setConnectionStatus("disconnected");
      }
    };

    provider.on("sync", handleSync);
    provider.on("status", handleStatus);
    setReady(true);

    return () => {
      clearTimeout(timeoutId);
      provider.off("sync", handleSync);
      provider.off("status", handleStatus);
      bindingRef.current?.destroy();
      bindingRef.current = null;
      provider.destroy();
      yDoc.destroy();
      yDocRef.current = null;
      providerRef.current = null;
      genRef.current += 1;
      setReady(false);
    };
  }, [room]);

  const bindEditor = useCallback(
    (
      editorInstance: editor.IStandaloneCodeEditor,
      monaco: typeof import("monaco-editor"),
      yText?: Y.Text,
    ) => {
      const yDoc = yDocRef.current;
      if (!yDoc) return;

      const text = yText ?? yDoc.getText("monaco");

      const model = editorInstance.getModel();
      if (!model) return;

      // Capture the generation at call time. If the effect re-runs (StrictMode,
      // room change, etc.), genRef increments — stale async callbacks are ignored.
      const gen = genRef.current;

      // Clean up previous binding
      bindingRef.current?.destroy();
      bindingRef.current = null;

      // Dynamically import MonacoBinding to avoid SSR "window is not defined"
      getMonacoBinding()
        .then((MonacoBinding) => {
          // Stale callback guard (primary): if genRef changed, a new effect cycle
          // started and this callback's captured yDoc/provider are all obsolete.
          if (gen !== genRef.current) return;
          // Secondary guard: the yDoc itself was replaced/destroyed
          if (yDocRef.current !== yDoc) return;

          const binding = new MonacoBinding(text, model, new Set([editorInstance]));
          // If a newer call already set a binding, discard this one
          if (bindingRef.current) {
            binding.destroy();
          } else {
            bindingRef.current = binding;
          }
        })
        .catch((err) => {
          console.error("Failed to load y-monaco binding:", err);
        });

      // Update cursor position and last activity in Liveblocks presence
      editorInstance.onDidChangeCursorPosition((e) => {
        room?.updatePresence({
          cursor: {
            lineNumber: e.position.lineNumber,
            column: e.position.column,
          },
          lastActivity: Date.now(),
        });
      });
    },
    [room],
  );

  const disconnectEditor = useCallback(() => {
    bindingRef.current?.destroy();
    bindingRef.current = null;
  }, []);

  // Periodic presence update to track lastActivity
  useEffect(() => {
    if (!room) return;
    const interval = setInterval(() => {
      room.updatePresence({
        lastActivity: Date.now(),
        isOnline: true,
      });
    }, 30000);
    return () => clearInterval(interval);
  }, [room]);

  // Don't render children until the Y.Doc and provider are actually created.
  // This is critical: MonacoEditor's handleEditorMount runs bindEditor which
  // reads yDocRef.current. If children render before the real Y.Doc exists,
  // bindEditor returns early and the y-monaco binding is never established.
  if (!ready || !yDocRef.current || !providerRef.current) {
    return (
      <div className="flex-1 flex items-center justify-center text-gray-400">
        <div className="flex flex-col items-center gap-3">
          <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
          <span className="text-sm">Connecting to collaboration server...</span>
        </div>
      </div>
    );
  }

  return (
    <YjsContext.Provider
      value={{
        yDoc: yDocRef.current,
        provider: providerRef.current,
        bindEditor,
        disconnectEditor,
        connectionStatus,
        connectionError,
      }}
    >
      {children}
    </YjsContext.Provider>
  );
}

export function useYjs() {
  const ctx = useContext(YjsContext);
  if (!ctx) throw new Error("useYjs must be used within YjsProvider");
  return ctx;
}
