"use client";

import { LiveblocksProvider as LiveblocksProviderBase } from "@liveblocks/react";

export function LiveblocksProvider({ children }: { children: React.ReactNode }) {
  return (
    <LiveblocksProviderBase
      authEndpoint={async (room) => {
        let url = "/api/liveblocks-auth";
        // Only pass admin token on admin pages to prevent identity leak
        if (typeof window !== "undefined") {
          const isAdminPage = window.location.pathname.startsWith("/admin");
          if (isAdminPage) {
            const adminToken = sessionStorage.getItem("admin_token");
            if (adminToken) {
              url = `/api/liveblocks-auth?adminToken=${encodeURIComponent(adminToken)}`;
            }
          }
        }
        const response = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ room }),
        });
        return response.json();
      }}
      throttle={16}
    >
      {children}
    </LiveblocksProviderBase>
  );
}
