# Prism Vault — Sudoku

A premium, animation-rich Sudoku PWA built with React, TanStack Start, Tailwind CSS v4, and Nitro. Deployable to Vercel and publishable to the Google Play Store as a Trusted Web Activity (TWA).

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | [TanStack Start](https://tanstack.com/start) (React 19) |
| Routing | [TanStack Router](https://tanstack.com/router) |
| Styling | [Tailwind CSS v4](https://tailwindcss.com) + Lightning CSS |
| Forms | [React Hook Form](https://react-hook-form.com) + Zod |
| UI Components | [Radix UI](https://www.radix-ui.com) primitives |
| Server Engine | [Nitro](https://nitro.unjs.io) (Vercel preset) |
| Package Manager | [pnpm](https://pnpm.io) v11+ |
| Runtime | Node.js 22.12+ |

## Project Structure

```
├── public/
│   ├── icon.svg              # SVG favicon source
│   ├── icon-192.png          # PWA icon 192×192
│   ├── icon-512.png          # PWA icon 512×512
│   ├── icon-maskable-192.png # Maskable icon 192×192
│   ├── icon-maskable-512.png # Maskable icon 512×512
│   ├── apple-touch-icon.png  # Apple touch icon 180×180
│   ├── favicon.png           # Favicon 32×32
│   ├── manifest.webmanifest  # PWA manifest
│   ├── robots.txt
│   └── sw.js                 # Service worker
├── src/
│   ├── components/ui/        # Radix-based UI components
│   ├── hooks/                # Custom React hooks
│   ├── lib/
│   │   ├── api/              # Server functions
│   │   ├── sudoku/           # Sudoku engine + storage
│   │   ├── utils.ts          # Utility functions (cn, etc.)
│   │   ├── error-capture.ts  # SSR error capture
│   │   ├── error-page.ts     # Error page HTML
│   │   └── config.server.ts  # Server config
│   ├── routes/
│   │   ├── __root.tsx        # Root layout (PWA meta, SW registration)
│   │   ├── index.tsx         # Home / difficulty selector
│   │   └── play.tsx          # Sudoku game board
│   ├── server.ts             # Server entry (SSR error wrapper)
│   ├── router.tsx            # Router config
│   ├── routeTree.gen.ts      # Auto-generated route tree
│   └── styles.css            # Global styles
├── vercel.json               # Vercel deployment config
├── twa-manifest.json         # Bubblewrap TWA reference config
├── pnpm-workspace.yaml       # pnpm build permissions
├── vite.config.ts            # Vite + Nitro config
├── tsconfig.json             # TypeScript config
└── package.json
```

## Getting Started

### Prerequisites

- **Node.js 22.12+** — install via [fnm](https://github.com/Schniz/fnm), [nvm](https://github.com/nvm-sh/nvm), or [volta](https://volta.sh)
- **pnpm 11+** — `npm install -g pnpm`

### Installation

```bash
# Clone the repository
git clone <your-repo-url>
cd prism-vault-sudoku

# Install dependencies
pnpm install

# Start the dev server
pnpm dev
```

The app runs at [http://localhost:8080](http://localhost:8080).

### Available Scripts

| Command | Description |
|---------|-------------|
| `pnpm dev` | Start the development server |
| `pnpm build` | Production build (outputs to `.vercel/output/`) |
| `pnpm build:dev` | Development-mode build |
| `pnpm preview` | Preview the production build locally |
| `pnpm lint` | Run ESLint |
| `pnpm format` | Format code with Prettier |

## Development

### Tech Details

- **Path aliases:** `@/` maps to `src/` (configured in both `tsconfig.json` and `vite.config.ts`)
- **CSS:** Tailwind v4 with Lightning CSS transformer
- **SSR:** TanStack Start handles server-side rendering; custom error wrapping in `src/server.ts`
- **PWA:** Service worker (`public/sw.js`) with stale-while-revalidate caching and offline navigation fallback

### Sudoku Engine

The core game logic lives in `src/lib/sudoku/engine.ts`:

- `generatePuzzle(difficulty)` — generates a valid puzzle + solution pair
- `allConflicts(board)` — returns indices of conflicting cells
- `findHint(board, solution)` — finds the next solvable cell
- `isComplete(board, solution)` — checks win condition

Game state is persisted to `localStorage` via `src/lib/sudoku/storage.ts`.

## Deployment to Vercel

The project is pre-configured for Vercel deployment via GitHub.

### Step 1: Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin <your-github-repo-url>
git push -u origin main
```

### Step 2: Connect to Vercel

1. Go to [vercel.com](https://vercel.com) and sign in
2. Click **"Add New Project"**
3. Import your GitHub repository
4. Vercel will auto-detect the configuration from `vercel.json`:
   - **Build Command:** `pnpm build`
   - **Output Directory:** `.vercel/output`
   - **Install Command:** `pnpm install`
5. Click **Deploy**

### Step 3: Verify

Once deployed, verify:

- The app loads at your Vercel URL
- The PWA is installable (look for the install prompt in Chrome)
- The service worker registers correctly (check DevTools → Application → Service Workers)

### Environment Variables

If you add environment variables later, configure them in the Vercel dashboard under **Settings → Environment Variables**.

## Publishing to the Google Play Store

This section covers wrapping the deployed PWA as a **Trusted Web Activity (TWA)** using [Bubblewrap](https://github.com/googlechromelabs/bubblewrap) and publishing to the Google Play Store.

### Prerequisites

1. **Deployed PWA** — your app must be live on Vercel (HTTPS required)
2. **Google Play Console account** — [$25 one-time registration fee](https://play.google.com/console/signup)
3. **Android Studio** — [Download](https://developer.android.com/studio)
4. **Java Development Kit (JDK) 17+** — bundled with Android Studio
5. **Node.js** — already installed

### Step 1: Install Android Studio & SDK

1. Install [Android Studio](https://developer.android.com/studio)
2. Open Android Studio → **SDK Manager** → install:
   - Android SDK Platform (API 34 or latest)
   - Android SDK Build-Tools
   - Android SDK Command-line Tools
3. Set environment variables (add to `~/.zshrc` or `~/.bashrc`):

```bash
export ANDROID_HOME="$HOME/Library/Android/sdk"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"
```

4. Verify:

```bash
adb --version
sdkmanager --version
```

### Step 2: Install Bubblewrap

```bash
npm install -g @bubblewrap/cli
```

> **Source:** [Bubblewrap GitHub](https://github.com/googlechromelabs/bubblewrap)

### Step 3: Initialize the TWA Project

After your PWA is deployed and live on Vercel, run:

```bash
bubblewrap init --manifest=https://your-app-url.vercel.app/manifest.webmanifest
```

Bubblewrap will prompt you for:

| Prompt | Example Value |
|--------|--------------|
| **Domain** | `your-app-url.vercel.app` |
| **App name** | `Prism Vault Sudoku` |
| **Package ID** | `com.prismvault.sudoku` |
| **Key store path** | Press Enter for default (`.jks` file) |
| **Key store password** | Choose a strong password |
| **Key password** | Same as above (or different) |
| **Key owner** | Your name or org |

This creates an `android/` directory with the full Android project.

> **Important:** Remember your keystore password. You need the same signing key for every future update.

### Step 4: Build the AAB (Android App Bundle)

```bash
bubblewrap build
```

This generates `app-release-signed.aab` in your project directory.

### Step 5: Set Up Digital Asset Links

Your PWA must prove ownership to the TWA. After you get your signing key fingerprint from Bubblewrap output or run:

```bash
keytool -list -v -keystore <keystore-path> -storepass <your-password>
```

> The keystore path and alias are printed during `bubblewrap init`. Use the SHA-256 fingerprint from that output.

Create `public/.well-known/assetlinks.json` on your Vercel deployment:

```json
[
  {
    "relation": ["delegate_permission/common.handle_all_urls"],
    "target": {
      "namespace": "android_app",
      "package_name": "com.prismvault.sudoku",
      "sha256_cert_fingerprints": [
        "YOUR_SHA256_FINGERPRINT_HERE"
      ]
    }
  }
```

Push this file and verify it's accessible at:
```
https://your-app-url.vercel.app/.well-known/assetlinks.json
```

You can verify the file is valid using Google's [Statement List Generator](https://developers.google.com/digital-asset-links/tools/generator).

### Step 6: Create Store Listing

In the [Google Play Console](https://play.google.com/console):

1. Click **"Create App"**
2. Fill in:

| Field | Value |
|-------|-------|
| **App name** | Prism Vault Sudoku |
| **Default language** | English |
| **App or game** | Game |
| **Free or paid** | Free |

3. **Store Listing** — upload:

| Asset | Requirements |
|-------|-------------|
| **App icon** | 512×512 px, 32-bit PNG (use `public/icon-512.png`) |
| **Feature graphic** | 1024×500 px, JPG or PNG |
| **Phone screenshots** | 2–8 screenshots, min 320px, max 3840px, 16:9 or 9:16 aspect ratio |
| **Short description** | Max 80 characters |
| **Full description** | Max 4000 characters |

> **Tip:** Take screenshots using Android Studio's emulator or a physical device. For a Sudoku app, capture the home screen, difficulty selector, in-game board, and completion overlay.

4. **Privacy Policy** — you must provide a URL. Create a simple page at `/privacy` or host it externally. Example:

```
# Privacy Policy

Prism Vault Sudoku does not collect, store, or transmit any personal data.
Game progress is stored locally in your browser's localStorage.
No analytics, tracking, or third-party data sharing occurs.
```

### Step 7: Content Rating

Complete the **Content Rating** questionnaire in Play Console. For a puzzle game with no user-generated content, you'll likely get an **Everyone** rating.

### Step 8: Set Target Audience

Under **Target audience and content**, select:
- **Age group:** Suitable for all ages
- **Appeal to children:** No (unless targeting kids)

### Step 9: Upload & Release

1. Go to **Production** → **Create new release**
2. Upload `app-release-signed.aab`
3. Add release notes
4. Click **Review release**
5. Click **Start rollout to Production**

Google's review typically takes **1–7 days** for first submissions.

### Step 10: Post-Launch Verification

After approval:

1. Install from the Play Store on an Android device
2. Verify the TWA opens your Vercel-deployed app in full-screen
3. Verify offline support (turn off WiFi/mobile data)
4. Verify the app icon appears correctly on the home screen

### Updating the App

When you push code changes to GitHub:

1. Vercel auto-deploys the updated PWA
2. TWA users get the latest content automatically (it's a web wrapper)
3. For TWA structural changes (icon, package name, permissions), build a new AAB with `bubblewrap build` and upload to Play Console

## Troubleshooting

### Build fails with `ERR_PNPM_IGNORED_BUILDS`

pnpm v11 blocks build scripts by default. The `pnpm-workspace.yaml` already allows esbuild:

```yaml
allowBuilds:
  esbuild: true
```

If other native packages need builds, add them here.

### Vercel deployment returns 404

Ensure the build output goes to `.vercel/output/`. Run locally:

```bash
pnpm build
ls .vercel/output/
```

### TWA shows browser chrome (address bar)

The Digital Asset Links file is missing or invalid. Verify:

1. `assetlinks.json` is accessible at `/.well-known/assetlinks.json`
2. The SHA-256 fingerprint matches your signing key
3. The `package_name` matches exactly

### Service worker not registering

- Ensure the app is served over HTTPS (Vercel does this automatically)
- Check DevTools → Application → Service Workers for errors
- The SW only caches GET requests

## License

Private — All rights reserved.
