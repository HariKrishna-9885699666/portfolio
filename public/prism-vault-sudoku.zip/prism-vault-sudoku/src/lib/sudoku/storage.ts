import type { Board, Difficulty, Notes } from "./engine";

const KEY = "prism-vault-game-v1";
const STATS_KEY = "prism-vault-stats-v1";

export interface SavedGame {
  puzzle: Board;
  solution: Board;
  board: Board;
  notes: Notes;
  difficulty: Difficulty;
  elapsedSec: number;
  mistakes: number;
  hintsUsed: number;
  history: { board: Board; notes: Notes }[];
  startedAt: number;
}

export interface Stats {
  solved: number;
  bestTimes: Partial<Record<Difficulty, number>>;
  streak: number;
  lastSolvedDate?: string;
}

export function loadGame(): SavedGame | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function saveGame(g: SavedGame | null) {
  if (typeof window === "undefined") return;
  if (!g) localStorage.removeItem(KEY);
  else localStorage.setItem(KEY, JSON.stringify(g));
}

export function loadStats(): Stats {
  if (typeof window === "undefined") return { solved: 0, bestTimes: {}, streak: 0 };
  try {
    const raw = localStorage.getItem(STATS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return { solved: 0, bestTimes: {}, streak: 0 };
}

export function recordSolve(difficulty: Difficulty, seconds: number) {
  const stats = loadStats();
  stats.solved += 1;
  const prev = stats.bestTimes[difficulty];
  if (!prev || seconds < prev) stats.bestTimes[difficulty] = seconds;
  const today = new Date().toISOString().slice(0, 10);
  if (stats.lastSolvedDate !== today) {
    const y = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    stats.streak = stats.lastSolvedDate === y ? stats.streak + 1 : 1;
    stats.lastSolvedDate = today;
  }
  localStorage.setItem(STATS_KEY, JSON.stringify(stats));
  return stats;
}