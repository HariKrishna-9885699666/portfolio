export type Cell = number; // 0 = empty
export type Board = Cell[]; // length 81
export type Notes = number[]; // bitmask per cell, bit 1<<n means candidate n (1..9)
export type Difficulty = "beginner" | "easy" | "medium" | "hard" | "expert";

const HOLES: Record<Difficulty, number> = {
  beginner: 36,
  easy: 44,
  medium: 50,
  hard: 55,
  expert: 58,
};

export const DIFFICULTIES: Difficulty[] = ["beginner", "easy", "medium", "hard", "expert"];

function shuffle<T>(arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function basePattern(r: number, c: number): number {
  return (3 * (r % 3) + Math.floor(r / 3) + c) % 9;
}

function generateSolution(): Board {
  const rBase = [0, 1, 2];
  const rows = shuffle(rBase).flatMap((g) => shuffle(rBase).map((r) => g * 3 + r));
  const cols = shuffle(rBase).flatMap((g) => shuffle(rBase).map((c) => g * 3 + c));
  const nums = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]);
  const board: Board = new Array(81).fill(0);
  for (let r = 0; r < 9; r++) {
    for (let c = 0; c < 9; c++) {
      board[r * 9 + c] = nums[basePattern(rows[r], cols[c])];
    }
  }
  return board;
}

export function generatePuzzle(difficulty: Difficulty): { puzzle: Board; solution: Board } {
  const solution = generateSolution();
  const puzzle = solution.slice();
  const holes = HOLES[difficulty];
  const indices = shuffle(Array.from({ length: 81 }, (_, i) => i));
  for (let i = 0; i < holes; i++) puzzle[indices[i]] = 0;
  return { puzzle, solution };
}

export function getConflicts(board: Board, index: number): Set<number> {
  const conflicts = new Set<number>();
  const v = board[index];
  if (!v) return conflicts;
  const r = Math.floor(index / 9);
  const c = index % 9;
  const br = Math.floor(r / 3) * 3;
  const bc = Math.floor(c / 3) * 3;
  for (let i = 0; i < 9; i++) {
    const ri = r * 9 + i;
    const ci = i * 9 + c;
    if (ri !== index && board[ri] === v) conflicts.add(ri);
    if (ci !== index && board[ci] === v) conflicts.add(ci);
  }
  for (let dr = 0; dr < 3; dr++) {
    for (let dc = 0; dc < 3; dc++) {
      const idx = (br + dr) * 9 + (bc + dc);
      if (idx !== index && board[idx] === v) conflicts.add(idx);
    }
  }
  return conflicts;
}

export function allConflicts(board: Board): Set<number> {
  const all = new Set<number>();
  for (let i = 0; i < 81; i++) {
    if (board[i]) {
      const c = getConflicts(board, i);
      if (c.size) {
        all.add(i);
        c.forEach((x) => all.add(x));
      }
    }
  }
  return all;
}

export function isComplete(board: Board, solution: Board): boolean {
  for (let i = 0; i < 81; i++) if (board[i] !== solution[i]) return false;
  return true;
}

export function countRemaining(board: Board, n: number): number {
  let c = 0;
  for (let i = 0; i < 81; i++) if (board[i] === n) c++;
  return 9 - c;
}

export function findHint(board: Board, solution: Board): { index: number; value: number } | null {
  // Naked single first
  for (let i = 0; i < 81; i++) {
    if (board[i] !== 0) continue;
    const candidates = candidatesFor(board, i);
    if (candidates.length === 1) return { index: i, value: candidates[0] };
  }
  // Fallback: first empty using solution
  for (let i = 0; i < 81; i++) if (board[i] === 0) return { index: i, value: solution[i] };
  return null;
}

export function candidatesFor(board: Board, index: number): number[] {
  const r = Math.floor(index / 9);
  const c = index % 9;
  const used = new Set<number>();
  for (let i = 0; i < 9; i++) {
    used.add(board[r * 9 + i]);
    used.add(board[i * 9 + c]);
  }
  const br = Math.floor(r / 3) * 3;
  const bc = Math.floor(c / 3) * 3;
  for (let dr = 0; dr < 3; dr++) for (let dc = 0; dc < 3; dc++) used.add(board[(br + dr) * 9 + (bc + dc)]);
  const out: number[] = [];
  for (let n = 1; n <= 9; n++) if (!used.has(n)) out.push(n);
  return out;
}

export function relatedIndices(index: number): Set<number> {
  const r = Math.floor(index / 9);
  const c = index % 9;
  const br = Math.floor(r / 3) * 3;
  const bc = Math.floor(c / 3) * 3;
  const set = new Set<number>();
  for (let i = 0; i < 9; i++) {
    set.add(r * 9 + i);
    set.add(i * 9 + c);
  }
  for (let dr = 0; dr < 3; dr++) for (let dc = 0; dc < 3; dc++) set.add((br + dr) * 9 + (bc + dc));
  return set;
}