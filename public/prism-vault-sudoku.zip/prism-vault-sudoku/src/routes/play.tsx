import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  DIFFICULTIES,
  allConflicts,
  countRemaining,
  findHint,
  generatePuzzle,
  isComplete,
  relatedIndices,
  type Difficulty,
} from "@/lib/sudoku/engine";
import { loadGame, recordSolve, saveGame, type SavedGame } from "@/lib/sudoku/storage";

type Search = { d?: Difficulty; new?: number };

export const Route = createFileRoute("/play")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    d: DIFFICULTIES.includes(search.d as Difficulty) ? (search.d as Difficulty) : undefined,
    new: search.new ? 1 : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Solving — Prism Vault" },
      { name: "description", content: "Solve a Sudoku puzzle in the Ember Vault." },
    ],
  }),
  component: Play,
});

function newGame(difficulty: Difficulty): SavedGame {
  const { puzzle, solution } = generatePuzzle(difficulty);
  return {
    puzzle,
    solution,
    board: puzzle.slice(),
    notes: new Array(81).fill(0),
    difficulty,
    elapsedSec: 0,
    mistakes: 0,
    hintsUsed: 0,
    history: [],
    startedAt: Date.now(),
  };
}

function Play() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const [game, setGame] = useState<SavedGame | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [notesMode, setNotesMode] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [paused, setPaused] = useState(false);
  const [shake, setShake] = useState(false);
  const [completed, setCompleted] = useState(false);
  const startTimeRef = useRef<number>(Date.now());

  // Init game
  useEffect(() => {
    const existing = loadGame();
    let g: SavedGame;
    if (search.new && search.d) {
      g = newGame(search.d);
    } else if (existing) {
      g = existing;
    } else {
      g = newGame(search.d ?? "medium");
    }
    setGame(g);
    setElapsed(g.elapsedSec);
    startTimeRef.current = Date.now() - g.elapsedSec * 1000;
    // strip search params so refresh resumes cleanly
    if (search.new || search.d) {
      navigate({ to: "/play", search: {}, replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Timer
  useEffect(() => {
    if (!game || paused || completed) return;
    const id = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startTimeRef.current) / 1000));
    }, 1000);
    return () => clearInterval(id);
  }, [game, paused, completed]);

  // Auto-save
  useEffect(() => {
    if (!game || completed) return;
    saveGame({ ...game, elapsedSec: elapsed });
  }, [game, elapsed, completed]);

  const conflicts = useMemo(() => (game ? allConflicts(game.board) : new Set<number>()), [game]);

  const placeNumber = useCallback(
    (n: number) => {
      if (!game || selected === null || completed) return;
      if (game.puzzle[selected] !== 0) return; // given cell
      const history = [...game.history, { board: game.board.slice(), notes: game.notes.slice() }].slice(-50);
      const board = game.board.slice();
      const notes = game.notes.slice();
      if (notesMode && n !== 0) {
        notes[selected] = notes[selected] ^ (1 << n);
      } else {
        const prev = board[selected];
        board[selected] = n;
        notes[selected] = 0;
        // clear notes for same number in related cells
        if (n !== 0) {
          relatedIndices(selected).forEach((idx) => {
            if (notes[idx] & (1 << n)) notes[idx] = notes[idx] ^ (1 << n);
          });
        }
        // mistake = wrong placement
        let mistakes = game.mistakes;
        if (n !== 0 && n !== game.solution[selected]) {
          mistakes += 1;
          setShake(true);
          setTimeout(() => setShake(false), 250);
        }
        const next = { ...game, board, notes, history, mistakes };
        setGame(next);
        if (isComplete(board, game.solution)) {
          setCompleted(true);
          recordSolve(game.difficulty, elapsed);
          saveGame(null);
        }
        return;
        void prev;
      }
      setGame({ ...game, board, notes, history });
    },
    [game, selected, notesMode, completed, elapsed]
  );

  const erase = useCallback(() => {
    if (!game || selected === null) return;
    if (game.puzzle[selected] !== 0) return;
    const history = [...game.history, { board: game.board.slice(), notes: game.notes.slice() }].slice(-50);
    const board = game.board.slice();
    const notes = game.notes.slice();
    board[selected] = 0;
    notes[selected] = 0;
    setGame({ ...game, board, notes, history });
  }, [game, selected]);

  const undo = useCallback(() => {
    if (!game || game.history.length === 0) return;
    const last = game.history[game.history.length - 1];
    setGame({
      ...game,
      board: last.board.slice(),
      notes: last.notes.slice(),
      history: game.history.slice(0, -1),
    });
  }, [game]);

  const useHint = useCallback(() => {
    if (!game) return;
    const hint = findHint(game.board, game.solution);
    if (!hint) return;
    setSelected(hint.index);
    const history = [...game.history, { board: game.board.slice(), notes: game.notes.slice() }].slice(-50);
    const board = game.board.slice();
    board[hint.index] = hint.value;
    const notes = game.notes.slice();
    notes[hint.index] = 0;
    const next: SavedGame = { ...game, board, notes, history, hintsUsed: game.hintsUsed + 1 };
    setGame(next);
    if (isComplete(board, game.solution)) {
      setCompleted(true);
      recordSolve(game.difficulty, elapsed);
      saveGame(null);
    }
  }, [game, elapsed]);

  if (!game) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="text-sm text-muted-foreground">Loading vault…</div>
      </div>
    );
  }

  const selectedValue = selected !== null ? game.board[selected] : 0;
  const related = selected !== null ? relatedIndices(selected) : new Set<number>();

  const fmt = (s: number) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="mx-auto flex min-h-screen max-w-md flex-col px-5 pb-6 pt-10">
        {/* Header */}
        <header className="mb-6 flex items-center justify-between">
          <Link to="/" className="flex flex-col">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              ← Vault Chamber
            </span>
            <span className="font-serif text-lg capitalize text-foreground">{game.difficulty}</span>
          </Link>
          <div className="flex items-center gap-4">
            <div className="flex flex-col items-end">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                Duration
              </span>
              <span className="font-medium tabular-nums text-primary">{fmt(elapsed)}</span>
            </div>
            <button
              onClick={() => setPaused((p) => !p)}
              aria-label={paused ? "Resume" : "Pause"}
              className="flex size-10 items-center justify-center rounded-full bg-card ring-1 ring-border transition-transform active:scale-95"
            >
              {paused ? (
                <svg viewBox="0 0 24 24" fill="currentColor" className="size-4 text-primary">
                  <path d="M8 5v14l11-7z" />
                </svg>
              ) : (
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-4 text-muted-foreground">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 5.25v13.5m-7.5-13.5v13.5" />
                </svg>
              )}
            </button>
          </div>
        </header>

        {/* Board */}
        <div className={`relative ${shake ? "animate-shake" : ""}`}>
          <div
            className={`aspect-square w-full rounded-2xl bg-card p-1.5 shadow-2xl ring-1 ring-border animate-vault-rise ${
              paused ? "blur-md pointer-events-none" : ""
            }`}
          >
            <Board
              game={game}
              selected={selected}
              setSelected={setSelected}
              selectedValue={selectedValue}
              related={related}
              conflicts={conflicts}
            />
          </div>
          {paused && (
            <div className="absolute inset-0 flex items-center justify-center">
              <button
                onClick={() => setPaused(false)}
                className="rounded-full bg-primary px-6 py-3 font-serif text-primary-foreground shadow-[0_0_30px_oklch(0.84_0.16_85/0.5)]"
              >
                Resume
              </button>
            </div>
          )}
        </div>

        {/* Action bar */}
        <div className="mt-6 grid grid-cols-4 gap-3">
          <ActionButton label="Undo" onClick={undo} disabled={game.history.length === 0}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 15L3 9m0 0l6-6M3 9h12a6 6 0 010 12h-3" />
            </svg>
          </ActionButton>
          <ActionButton label="Erase" onClick={erase}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 21l8-8m0 0l8-8m-8 8l8 8M11 13L3 5" />
            </svg>
          </ActionButton>
          <ActionButton
            label={notesMode ? "Notes On" : "Notes"}
            onClick={() => setNotesMode((n) => !n)}
            active={notesMode}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L6.832 19.82a4.5 4.5 0 0 1-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 0 1 1.13-1.897L16.863 4.487Zm0 0L19.5 7.125" />
            </svg>
          </ActionButton>
          <ActionButton label={`Hint (${game.hintsUsed})`} onClick={useHint}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z" />
            </svg>
          </ActionButton>
        </div>

        {/* Number pad */}
        <div className="mt-auto pt-6">
          <div className="grid grid-cols-5 gap-2">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => {
              const remaining = countRemaining(game.board, n);
              const done = remaining <= 0;
              return (
                <button
                  key={n}
                  onClick={() => placeNumber(n)}
                  disabled={done && !notesMode}
                  className={`relative flex h-14 flex-col items-center justify-center rounded-xl bg-card ring-1 ring-border transition-all active:scale-95 active:ring-primary/60 ${
                    done ? "opacity-30" : ""
                  }`}
                >
                  <span className="font-serif text-xl">{n}</span>
                  <span className="text-[8px] font-medium text-muted-foreground">{Math.max(0, remaining)}</span>
                </button>
              );
            })}
            <button
              onClick={erase}
              className="flex h-14 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-[0_0_20px_oklch(0.84_0.16_85/0.3)] transition-transform active:scale-95"
              aria-label="Clear cell"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="size-5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {completed && (
        <CompleteOverlay
          difficulty={game.difficulty}
          time={elapsed}
          mistakes={game.mistakes}
          hints={game.hintsUsed}
        />
      )}
    </div>
  );
}

function ActionButton({
  label,
  onClick,
  children,
  active,
  disabled,
}: {
  label: string;
  onClick: () => void;
  children: React.ReactNode;
  active?: boolean;
  disabled?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="group flex flex-col items-center gap-1 disabled:opacity-40"
    >
      <div
        className={`flex size-12 items-center justify-center rounded-xl ring-1 transition-all group-active:translate-y-px ${
          active
            ? "bg-primary/15 text-primary ring-primary/50"
            : "bg-card text-muted-foreground ring-border"
        }`}
      >
        {children}
      </div>
      <span
        className={`text-[10px] font-medium uppercase tracking-tight ${
          active ? "text-primary" : "text-muted-foreground"
        }`}
      >
        {label}
      </span>
    </button>
  );
}

function Board({
  game,
  selected,
  setSelected,
  selectedValue,
  related,
  conflicts,
}: {
  game: SavedGame;
  selected: number | null;
  setSelected: (i: number) => void;
  selectedValue: number;
  related: Set<number>;
  conflicts: Set<number>;
}) {
  return (
    <div className="grid h-full grid-cols-3 grid-rows-3 gap-1">
      {Array.from({ length: 9 }, (_, blockIdx) => {
        const isDarkBlock =
          (Math.floor(blockIdx / 3) + (blockIdx % 3)) % 2 === 1;
        return (
          <div
            key={blockIdx}
            className={`grid grid-cols-3 grid-rows-3 gap-0.5 overflow-hidden rounded-lg ring-1 ring-border/50 ${
              isDarkBlock ? "bg-secondary/50" : "bg-secondary/25"
            }`}
          >
            {Array.from({ length: 9 }, (_, cellIdx) => {
              const br = Math.floor(blockIdx / 3) * 3;
              const bc = (blockIdx % 3) * 3;
              const r = br + Math.floor(cellIdx / 3);
              const c = bc + (cellIdx % 3);
              const idx = r * 9 + c;
              return (
                <Cell
                  key={idx}
                  idx={idx}
                  game={game}
                  selected={selected}
                  onSelect={setSelected}
                  selectedValue={selectedValue}
                  isRelated={related.has(idx)}
                  isConflict={conflicts.has(idx)}
                />
              );
            })}
          </div>
        );
      })}
    </div>
  );
}

function Cell({
  idx,
  game,
  selected,
  onSelect,
  selectedValue,
  isRelated,
  isConflict,
}: {
  idx: number;
  game: SavedGame;
  selected: number | null;
  onSelect: (i: number) => void;
  selectedValue: number;
  isRelated: boolean;
  isConflict: boolean;
}) {
  const value = game.board[idx];
  const isGiven = game.puzzle[idx] !== 0;
  const isSelected = selected === idx;
  const isMatch = value !== 0 && selectedValue !== 0 && value === selectedValue && !isSelected;
  const notes = game.notes[idx];

  const bg = isSelected
    ? "bg-primary text-primary-foreground ring-2 ring-primary/80"
    : isMatch
    ? "bg-primary/15"
    : isRelated
    ? "bg-primary/5"
    : "bg-background/60";

  const textColor = isSelected
    ? "text-primary-foreground"
    : isConflict
    ? "text-destructive"
    : isGiven
    ? "text-foreground/90"
    : "text-primary";

  return (
    <button
      onClick={() => onSelect(idx)}
      className={`relative flex aspect-square items-center justify-center font-serif text-lg transition-colors ${bg}`}
    >
      {value !== 0 ? (
        <span className={`${textColor} ${!isGiven ? "animate-pop-in" : ""}`}>{value}</span>
      ) : notes ? (
        <div className="grid h-full w-full grid-cols-3 grid-rows-3 p-0.5 leading-none">
          {Array.from({ length: 9 }, (_, i) => {
            const n = i + 1;
            const on = (notes & (1 << n)) !== 0;
            return (
              <span
                key={n}
                className={`flex items-center justify-center text-[8px] font-medium ${
                  on ? "text-muted-foreground" : "text-transparent"
                }`}
              >
                {n}
              </span>
            );
          })}
        </div>
      ) : null}
    </button>
  );
}

function CompleteOverlay({
  difficulty,
  time,
  mistakes,
  hints,
}: {
  difficulty: Difficulty;
  time: number;
  mistakes: number;
  hints: number;
}) {
  const fmt = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/85 backdrop-blur-md">
      <div className="mx-6 max-w-sm rounded-3xl bg-card p-8 text-center ring-1 ring-primary/30 shadow-[0_0_60px_oklch(0.84_0.16_85/0.3)] animate-vault-rise">
        <div className="mx-auto mb-4 flex size-16 items-center justify-center rounded-full bg-primary text-primary-foreground animate-ember-pulse">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="size-7">
            <path strokeLinecap="round" strokeLinejoin="round" d="m4.5 12.75 6 6 9-13.5" />
          </svg>
        </div>
        <p className="text-[10px] uppercase tracking-[0.3em] text-primary">Vault Unlocked</p>
        <h2 className="mt-2 font-serif text-3xl capitalize italic">{difficulty} solved</h2>
        <div className="mt-6 grid grid-cols-3 gap-3 text-left">
          <Metric label="Time" value={fmt(time)} />
          <Metric label="Mistakes" value={mistakes.toString()} />
          <Metric label="Hints" value={hints.toString()} />
        </div>
        <div className="mt-6 flex flex-col gap-2">
          <Link
            to="/play"
            search={{ d: difficulty, new: 1 }}
            reloadDocument
            className="rounded-xl bg-primary py-3 font-serif text-primary-foreground transition-transform active:scale-95"
          >
            Next puzzle
          </Link>
          <Link
            to="/"
            className="rounded-xl bg-secondary py-3 font-serif text-foreground ring-1 ring-border transition-transform active:scale-95"
          >
            Return to vault
          </Link>
        </div>
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-secondary/60 p-3 ring-1 ring-border">
      <p className="text-[9px] uppercase tracking-[0.2em] text-muted-foreground">{label}</p>
      <p className="mt-1 font-serif text-base tabular-nums">{value}</p>
    </div>
  );
}