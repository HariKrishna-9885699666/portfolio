import { createFileRoute, Link } from "@tanstack/react-router";
import { useTheme, type Theme } from "@/lib/theme";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Prism Vault" },
      { name: "description", content: "App settings and developer information." },
    ],
  }),
  component: Settings,
});

function Settings() {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="mx-auto flex min-h-screen max-w-md flex-col px-6 pb-10 pt-12">
        {/* Header */}
        <header className="mb-8 animate-vault-rise">
          <Link to="/" className="mb-4 inline-block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              ← Back to Vault
            </span>
          </Link>
          <h1 className="font-serif text-4xl font-medium leading-none tracking-tight">
            Settings
          </h1>
        </header>

        {/* Appearance */}
        <section className="mb-6 animate-vault-rise" style={{ animationDelay: "50ms" }}>
          <p className="mb-3 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            Appearance
          </p>
          <div className="rounded-2xl bg-card p-5 ring-1 ring-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-xl bg-secondary ring-1 ring-border">
                  {theme === "dark" ? (
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-5 text-primary">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M21.752 15.002A9.72 9.72 0 0 1 18 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 0 0 3 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 0 0 9.002-5.998Z" />
                    </svg>
                  ) : (
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-5 text-primary">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v2.25m6.364.386-1.591 1.591M21 12h-2.25m-.386 6.364-1.591-1.591M12 18.75V21m-4.773-4.227-1.591 1.591M5.25 12H3m4.227-4.773L5.636 5.636M15.75 12a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0Z" />
                    </svg>
                  )}
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Dark Mode</p>
                  <p className="text-xs text-muted-foreground">
                    {theme === "dark" ? "Ember Obsidian theme" : "Ember Light theme"}
                  </p>
                </div>
              </div>
              <Switch
                checked={theme === "dark"}
                onCheckedChange={toggleTheme}
                aria-label="Toggle dark mode"
              />
            </div>
          </div>
        </section>

        {/* Developer Info */}
        <section className="mb-6 animate-vault-rise" style={{ animationDelay: "100ms" }}>
          <p className="mb-3 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            Developer
          </p>
          <div className="rounded-2xl bg-card p-5 ring-1 ring-border">
            <div className="flex items-center gap-4">
              <div className="flex size-14 items-center justify-center rounded-full bg-primary/15 text-primary font-serif text-2xl ring-2 ring-primary/30">
                HK
              </div>
              <div>
                <p className="font-serif text-lg font-medium text-foreground">
                  Hari Krishna Anem
                </p>
                <p className="text-xs text-muted-foreground">
                  B.Tech (CSIT) · Hyderabad, India
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Contact */}
        <section className="mb-6 animate-vault-rise" style={{ animationDelay: "150ms" }}>
          <p className="mb-3 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            Contact
          </p>
          <div className="rounded-2xl bg-card ring-1 ring-border overflow-hidden">
            <a
              href="tel:+919885699666"
              className="flex items-center gap-4 p-4 transition-colors hover:bg-secondary"
            >
              <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-secondary ring-1 ring-border">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-4 text-muted-foreground">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z" />
                </svg>
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-[10px] uppercase tracking-[0.15em] text-muted-foreground">Phone</p>
                <p className="truncate text-sm font-medium text-foreground">+91 98856 99666</p>
              </div>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-4 shrink-0 text-muted-foreground">
                <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 6H5.25A2.25 2.25 0 0 0 3 8.25v10.5A2.25 2.25 0 0 0 5.25 21h10.5A2.25 2.25 0 0 0 18 18.75V10.5m-10.5 6L21 3m0 0h-5.25M21 3v5.25" />
              </svg>
            </a>
            <Separator />
            <a
              href="mailto:anemharikrishna@gmail.com"
              className="flex items-center gap-4 p-4 transition-colors hover:bg-secondary"
            >
              <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-secondary ring-1 ring-border">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-4 text-muted-foreground">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75" />
                </svg>
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-[10px] uppercase tracking-[0.15em] text-muted-foreground">Email</p>
                <p className="truncate text-sm font-medium text-foreground">anemharikrishna@gmail.com</p>
              </div>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-4 shrink-0 text-muted-foreground">
                <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 6H5.25A2.25 2.25 0 0 0 3 8.25v10.5A2.25 2.25 0 0 0 5.25 21h10.5A2.25 2.25 0 0 0 18 18.75V10.5m-10.5 6L21 3m0 0h-5.25M21 3v5.25" />
              </svg>
            </a>
          </div>
        </section>

        {/* Social Links */}
        <section className="mb-6 animate-vault-rise" style={{ animationDelay: "200ms" }}>
          <p className="mb-3 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            Links
          </p>
          <div className="rounded-2xl bg-card ring-1 ring-border overflow-hidden">
            <SocialLink
              href="https://github.com/HariKrishna-9885699666"
              icon={
                <svg viewBox="0 0 24 24" fill="currentColor" className="size-4 text-muted-foreground">
                  <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" />
                </svg>
              }
              label="GitHub"
            />
            <Separator />
            <SocialLink
              href="https://linkedin.com/in/anemharikrishna"
              icon={
                <svg viewBox="0 0 24 24" fill="currentColor" className="size-4 text-muted-foreground">
                  <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                </svg>
              }
              label="LinkedIn"
            />
            <Separator />
            <SocialLink
              href="https://hashnode.com/@HariKrishna-9885699666"
              icon={
                <svg viewBox="0 0 24 24" fill="currentColor" className="size-4 text-muted-foreground">
                  <path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 3.5a2.5 2.5 0 110 5 2.5 2.5 0 010-5zm0 12.5c-2.757 0-5.203-1.408-6.626-3.558.037-2.224 4.449-3.442 6.626-3.442s6.589 1.218 6.626 3.442A7.963 7.963 0 0112 18z" />
                </svg>
              }
              label="Blog"
            />
            <Separator />
            <SocialLink
              href="https://harikrishna.is-a-good.dev"
              icon={
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-4 text-muted-foreground">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 0 0 8.716-6.747M12 21a9.004 9.004 0 0 1-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 0 1 7.843 4.582M12 3a8.997 8.997 0 0 0-7.843 4.582m15.686 0A11.953 11.953 0 0 1 12 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0 1 21 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0 1 12 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 0 1 3 12c0-1.605.42-3.113 1.157-4.418" />
                </svg>
              }
              label="Portfolio"
            />
          </div>
        </section>

        {/* App Info */}
        <section className="mt-auto animate-vault-rise" style={{ animationDelay: "250ms" }}>
          <div className="rounded-2xl bg-card p-5 ring-1 ring-border text-center">
            <p className="font-serif text-lg text-foreground">Prism Vault</p>
            <p className="mt-1 text-xs text-muted-foreground">
              A premium Sudoku experience · v1.0.0
            </p>
            <p className="mt-3 text-[10px] text-muted-foreground/60">
              Built with React, TanStack Start & Tailwind CSS
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}

function SocialLink({
  href,
  icon,
  label,
}: {
  href: string;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-4 p-4 transition-colors hover:bg-secondary"
    >
      <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-secondary ring-1 ring-border">
        {icon}
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-foreground">{label}</p>
        <p className="truncate text-xs text-muted-foreground">
          {new URL(href).hostname}
        </p>
      </div>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-4 shrink-0 text-muted-foreground">
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 6H5.25A2.25 2.25 0 0 0 3 8.25v10.5A2.25 2.25 0 0 0 5.25 21h10.5A2.25 2.25 0 0 0 18 18.75V10.5m-10.5 6L21 3m0 0h-5.25M21 3v5.25" />
      </svg>
    </a>
  );
}
