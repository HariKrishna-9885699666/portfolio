import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { DIFFICULTIES, type Difficulty } from "@/lib/sudoku/engine";
import { loadGame, loadStats, type SavedGame, type Stats } from "@/lib/sudoku/storage";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Prism Vault — Sudoku" },
      { name: "description", content: "Enter the vault. A premium, animation-rich Sudoku experience." },
      { property: "og:title", content: "Prism Vault — Sudoku" },
      { property: "og:description", content: "Enter the vault. A premium, animation-rich Sudoku experience." },
    ],
  }),
  component: Index,
});

function Index() {
  const navigate = useNavigate();
  const [saved, setSaved] = useState<SavedGame | null>(null);
  const [stats, setStats] = useState<Stats>({ solved: 0, bestTimes: {}, streak: 0 });

  useEffect(() => {
    setSaved(loadGame());
    setStats(loadStats());
  }, []);

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="mx-auto flex min-h-screen max-w-md flex-col px-6 pb-10 pt-12">
        <header className="mb-10 animate-vault-rise">
          <div className="mb-2 flex items-center justify-between">
            <p className="text-[10px] font-medium uppercase tracking-[0.3em] text-primary/70">
              Prism Vault
            </p>
            <Link
              to="/settings"
              className="flex size-8 items-center justify-center rounded-lg bg-card text-muted-foreground ring-1 ring-border transition-colors hover:text-foreground hover:ring-primary/40"
              aria-label="Settings"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-4">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.325.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 0 1 1.37.49l1.296 2.247a1.125 1.125 0 0 1-.26 1.431l-1.003.827c-.293.241-.438.613-.43.992a7.723 7.723 0 0 1 0 .255c-.008.378.137.75.43.991l1.004.827c.424.35.534.955.26 1.43l-1.298 2.247a1.125 1.125 0 0 1-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.47 6.47 0 0 1-.22.128c-.331.183-.581.495-.644.869l-.213 1.281c-.09.543-.56.94-1.11.94h-2.594c-.55 0-1.019-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 0 1-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 0 1-1.369-.49l-1.297-2.247a1.125 1.125 0 0 1 .26-1.431l1.004-.827c.292-.24.437-.613.43-.991a6.932 6.932 0 0 1 0-.255c.007-.38-.138-.751-.43-.992l-1.004-.827a1.125 1.125 0 0 1-.26-1.43l1.297-2.247a1.125 1.125 0 0 1 1.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.086.22-.128.332-.183.582-.495.644-.869l.214-1.28Z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
              </svg>
            </Link>
          </div>
          <h1 className="font-serif text-5xl font-medium leading-none tracking-tight text-balance">
            Enter the
            <br />
            <span className="italic text-primary">Ember Chamber</span>
          </h1>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
            A Sudoku game that feels like unlocking a living puzzle vault.
          </p>
        </header>

        {saved && (
          <button
            onClick={() => navigate({ to: "/play" })}
            className="group mb-6 flex items-center justify-between rounded-2xl bg-card p-5 text-left ring-1 ring-border transition-all hover:ring-primary/50 active:scale-[0.98] animate-vault-rise"
          >
            <div>
              <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                Continue
              </p>
              <p className="mt-1 font-serif text-xl capitalize">{saved.difficulty}</p>
              <p className="mt-1 text-xs tabular-nums text-primary">
                {formatTime(saved.elapsedSec)} elapsed
              </p>
            </div>
            <div className="flex size-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-[0_0_24px_oklch(0.84_0.16_85/0.35)] transition-transform group-active:scale-95">
              <svg viewBox="0 0 24 24" fill="none" className="size-5" stroke="currentColor" strokeWidth="2.5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 12h14m-7-7 7 7-7 7" />
              </svg>
            </div>
          </button>
        )}

        <section className="mb-8 animate-vault-rise" style={{ animationDelay: "100ms" }}>
          <p className="mb-3 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            New Puzzle
          </p>
          <div className="grid grid-cols-1 gap-2">
            {DIFFICULTIES.map((d, i) => (
              <DifficultyButton key={d} difficulty={d} index={i} bestTime={stats.bestTimes[d]} />
            ))}
          </div>
        </section>

        <section className="mt-auto grid grid-cols-3 gap-3 animate-vault-rise" style={{ animationDelay: "200ms" }}>
          <Stat label="Solved" value={stats.solved.toString()} />
          <Stat label="Streak" value={stats.streak.toString()} />
          <Stat label="Best" value={bestOverall(stats)} />
        </section>
      </div>
    </div>
  );
}

function bestOverall(stats: Stats): string {
  const times = Object.values(stats.bestTimes).filter((t): t is number => !!t);
  if (!times.length) return "—";
  const min = Math.min(...times);
  return `${Math.floor(min / 60)}:${(min % 60).toString().padStart(2, "0")}`;
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-card p-3 ring-1 ring-border">
      <p className="text-[9px] uppercase tracking-[0.2em] text-muted-foreground">{label}</p>
      <p className="mt-1 font-serif text-lg tabular-nums">{value}</p>
    </div>
  );
}

function DifficultyButton({
  difficulty,
  index,
  bestTime,
}: {
  difficulty: Difficulty;
  index: number;
  bestTime?: number;
}) {
  return (
    <Link
      to="/play"
      search={{ d: difficulty, new: 1 }}
      className="group flex items-center justify-between rounded-xl bg-card p-4 ring-1 ring-border transition-all hover:bg-secondary hover:ring-primary/40 active:scale-[0.98]"
    >
      <div className="flex items-center gap-3">
        <div className="flex size-8 items-center justify-center rounded-md bg-secondary text-[10px] font-medium tabular-nums text-muted-foreground ring-1 ring-border">
          {"I".repeat(Math.min(5, index + 1))}
        </div>
        <span className="font-serif text-base capitalize">{difficulty}</span>
      </div>
      <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
        {bestTime
          ? `${Math.floor(bestTime / 60)}:${(bestTime % 60).toString().padStart(2, "0")}`
          : "—"}
      </span>
    </Link>
  );
}