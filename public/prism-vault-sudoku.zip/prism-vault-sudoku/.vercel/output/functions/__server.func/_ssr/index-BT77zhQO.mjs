import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { D as DIFFICULTIES } from "./router-Dl4GELfc.mjs";
import { l as loadGame, a as loadStats } from "./storage-BKErskxS.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
function Index() {
  const navigate = useNavigate();
  const [saved, setSaved] = reactExports.useState(null);
  const [stats, setStats] = reactExports.useState({
    solved: 0,
    bestTimes: {},
    streak: 0
  });
  reactExports.useEffect(() => {
    setSaved(loadGame());
    setStats(loadStats());
  }, []);
  const formatTime = (s) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-background text-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto flex min-h-screen max-w-md flex-col px-6 pb-10 pt-12", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "mb-10 animate-vault-rise", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-2 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] font-medium uppercase tracking-[0.3em] text-primary/70", children: "Prism Vault" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/settings", className: "flex size-8 items-center justify-center rounded-lg bg-card text-muted-foreground ring-1 ring-border transition-colors hover:text-foreground hover:ring-primary/40", "aria-label": "Settings", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", className: "size-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.325.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 0 1 1.37.49l1.296 2.247a1.125 1.125 0 0 1-.26 1.431l-1.003.827c-.293.241-.438.613-.43.992a7.723 7.723 0 0 1 0 .255c-.008.378.137.75.43.991l1.004.827c.424.35.534.955.26 1.43l-1.298 2.247a1.125 1.125 0 0 1-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.47 6.47 0 0 1-.22.128c-.331.183-.581.495-.644.869l-.213 1.281c-.09.543-.56.94-1.11.94h-2.594c-.55 0-1.019-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 0 1-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 0 1-1.369-.49l-1.297-2.247a1.125 1.125 0 0 1 .26-1.431l1.004-.827c.292-.24.437-.613.43-.991a6.932 6.932 0 0 1 0-.255c.007-.38-.138-.751-.43-.992l-1.004-.827a1.125 1.125 0 0 1-.26-1.43l1.297-2.247a1.125 1.125 0 0 1 1.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.086.22-.128.332-.183.582-.495.644-.869l.214-1.28Z" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "font-serif text-5xl font-medium leading-none tracking-tight text-balance", children: [
        "Enter the",
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "italic text-primary", children: "Ember Chamber" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-sm leading-relaxed text-muted-foreground", children: "A Sudoku game that feels like unlocking a living puzzle vault." })
    ] }),
    saved && /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => navigate({
      to: "/play"
    }), className: "group mb-6 flex items-center justify-between rounded-2xl bg-card p-5 text-left ring-1 ring-border transition-all hover:ring-primary/50 active:scale-[0.98] animate-vault-rise", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] uppercase tracking-[0.2em] text-muted-foreground", children: "Continue" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 font-serif text-xl capitalize", children: saved.difficulty }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-xs tabular-nums text-primary", children: [
          formatTime(saved.elapsedSec),
          " elapsed"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex size-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-[0_0_24px_oklch(0.84_0.16_85/0.35)] transition-transform group-active:scale-95", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 24 24", fill: "none", className: "size-5", stroke: "currentColor", strokeWidth: "2.5", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M5 12h14m-7-7 7 7-7 7" }) }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "mb-8 animate-vault-rise", style: {
      animationDelay: "100ms"
    }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-3 text-[10px] uppercase tracking-[0.2em] text-muted-foreground", children: "New Puzzle" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 gap-2", children: DIFFICULTIES.map((d, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(DifficultyButton, { difficulty: d, index: i, bestTime: stats.bestTimes[d] }, d)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "mt-auto grid grid-cols-3 gap-3 animate-vault-rise", style: {
      animationDelay: "200ms"
    }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Stat, { label: "Solved", value: stats.solved.toString() }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Stat, { label: "Streak", value: stats.streak.toString() }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Stat, { label: "Best", value: bestOverall(stats) })
    ] })
  ] }) });
}
function bestOverall(stats) {
  const times = Object.values(stats.bestTimes).filter((t) => !!t);
  if (!times.length) return "—";
  const min = Math.min(...times);
  return `${Math.floor(min / 60)}:${(min % 60).toString().padStart(2, "0")}`;
}
function Stat({
  label,
  value
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl bg-card p-3 ring-1 ring-border", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[9px] uppercase tracking-[0.2em] text-muted-foreground", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 font-serif text-lg tabular-nums", children: value })
  ] });
}
function DifficultyButton({
  difficulty,
  index,
  bestTime
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/play", search: {
    d: difficulty,
    new: 1
  }, className: "group flex items-center justify-between rounded-xl bg-card p-4 ring-1 ring-border transition-all hover:bg-secondary hover:ring-primary/40 active:scale-[0.98]", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex size-8 items-center justify-center rounded-md bg-secondary text-[10px] font-medium tabular-nums text-muted-foreground ring-1 ring-border", children: "I".repeat(Math.min(5, index + 1)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-serif text-base capitalize", children: difficulty })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] uppercase tracking-[0.2em] text-muted-foreground", children: bestTime ? `${Math.floor(bestTime / 60)}:${(bestTime % 60).toString().padStart(2, "0")}` : "—" })
  ] });
}
export {
  Index as component
};
