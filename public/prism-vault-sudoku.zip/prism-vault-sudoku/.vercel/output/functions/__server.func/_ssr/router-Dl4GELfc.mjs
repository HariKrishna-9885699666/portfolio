import { Q as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { Q as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { c as createRouter, a as createRootRouteWithContext, u as useRouter, L as Link, O as Outlet, H as HeadContent, S as Scripts, b as createFileRoute, l as lazyRouteComponent } from "../_libs/tanstack__react-router.mjs";
import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
const appCss = "/assets/styles-D-KJoTfC.css";
function NotFoundComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-4 text-xl font-semibold text-foreground", children: "Page not found" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist or has been moved." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Link,
      {
        to: "/",
        className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
        children: "Go home"
      }
    ) })
  ] }) });
}
function ErrorComponent({ error, reset }) {
  console.error(error);
  const router2 = useRouter();
  reactExports.useEffect(() => {
    console.error("Root error boundary:", error);
  }, [error]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-semibold tracking-tight text-foreground", children: "This page didn't load" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Something went wrong on our end. You can try refreshing or head back home." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex flex-wrap justify-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "Try again"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "Go home"
        }
      )
    ] })
  ] }) });
}
const Route$3 = createRootRouteWithContext()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { name: "theme-color", content: "#09090b" },
      { title: "Prism Vault — Sudoku" },
      { name: "description", content: "A premium, animation-rich Sudoku PWA. Enter the vault." },
      { property: "og:title", content: "Prism Vault — Sudoku" },
      { property: "og:description", content: "A premium, animation-rich Sudoku PWA. Enter the vault." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" }
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss
      },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;500;600&family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&display=swap"
      },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "icon", type: "image/svg+xml", href: "/icon.svg" },
      { rel: "icon", type: "image/png", sizes: "32x32", href: "/favicon.png" },
      { rel: "apple-touch-icon", sizes: "180x180", href: "/apple-touch-icon.png" }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "en", suppressHydrationWarning: true, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("head", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "script",
        {
          dangerouslySetInnerHTML: {
            __html: `try{var t=localStorage.getItem('prism-vault-theme');if(!t)t=matchMedia('(prefers-color-scheme:light)').matches?'light':'dark';document.documentElement.classList.add(t)}catch(e){}`
          }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {})
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  const { queryClient } = Route$3.useRouteContext();
  reactExports.useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {
      });
    }
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}) });
}
const $$splitComponentImporter$2 = () => import("./settings-C9ANvSx8.mjs");
const Route$2 = createFileRoute("/settings")({
  head: () => ({
    meta: [{
      title: "Settings — Prism Vault"
    }, {
      name: "description",
      content: "App settings and developer information."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const HOLES = {
  beginner: 36,
  easy: 44,
  medium: 50,
  hard: 55,
  expert: 58
};
const DIFFICULTIES = ["beginner", "easy", "medium", "hard", "expert"];
function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function basePattern(r, c) {
  return (3 * (r % 3) + Math.floor(r / 3) + c) % 9;
}
function generateSolution() {
  const rBase = [0, 1, 2];
  const rows = shuffle(rBase).flatMap((g) => shuffle(rBase).map((r) => g * 3 + r));
  const cols = shuffle(rBase).flatMap((g) => shuffle(rBase).map((c) => g * 3 + c));
  const nums = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]);
  const board = new Array(81).fill(0);
  for (let r = 0; r < 9; r++) {
    for (let c = 0; c < 9; c++) {
      board[r * 9 + c] = nums[basePattern(rows[r], cols[c])];
    }
  }
  return board;
}
function generatePuzzle(difficulty) {
  const solution = generateSolution();
  const puzzle = solution.slice();
  const holes = HOLES[difficulty];
  const indices = shuffle(Array.from({ length: 81 }, (_, i) => i));
  for (let i = 0; i < holes; i++) puzzle[indices[i]] = 0;
  return { puzzle, solution };
}
function getConflicts(board, index) {
  const conflicts = /* @__PURE__ */ new Set();
  const v = board[index];
  if (!v) return conflicts;
  const r = Math.floor(index / 9);
  const c = index % 9;
  const br = Math.floor(r / 3) * 3;
  const bc = Math.floor(c / 3) * 3;
  for (let i = 0; i < 9; i++) {
    const ri = r * 9 + i;
    const ci = i * 9 + c;
    if (ri !== index && board[ri] === v) conflicts.add(ri);
    if (ci !== index && board[ci] === v) conflicts.add(ci);
  }
  for (let dr = 0; dr < 3; dr++) {
    for (let dc = 0; dc < 3; dc++) {
      const idx = (br + dr) * 9 + (bc + dc);
      if (idx !== index && board[idx] === v) conflicts.add(idx);
    }
  }
  return conflicts;
}
function allConflicts(board) {
  const all = /* @__PURE__ */ new Set();
  for (let i = 0; i < 81; i++) {
    if (board[i]) {
      const c = getConflicts(board, i);
      if (c.size) {
        all.add(i);
        c.forEach((x) => all.add(x));
      }
    }
  }
  return all;
}
function isComplete(board, solution) {
  for (let i = 0; i < 81; i++) if (board[i] !== solution[i]) return false;
  return true;
}
function countRemaining(board, n) {
  let c = 0;
  for (let i = 0; i < 81; i++) if (board[i] === n) c++;
  return 9 - c;
}
function findHint(board, solution) {
  for (let i = 0; i < 81; i++) {
    if (board[i] !== 0) continue;
    const candidates = candidatesFor(board, i);
    if (candidates.length === 1) return { index: i, value: candidates[0] };
  }
  for (let i = 0; i < 81; i++) if (board[i] === 0) return { index: i, value: solution[i] };
  return null;
}
function candidatesFor(board, index) {
  const r = Math.floor(index / 9);
  const c = index % 9;
  const used = /* @__PURE__ */ new Set();
  for (let i = 0; i < 9; i++) {
    used.add(board[r * 9 + i]);
    used.add(board[i * 9 + c]);
  }
  const br = Math.floor(r / 3) * 3;
  const bc = Math.floor(c / 3) * 3;
  for (let dr = 0; dr < 3; dr++) for (let dc = 0; dc < 3; dc++) used.add(board[(br + dr) * 9 + (bc + dc)]);
  const out = [];
  for (let n = 1; n <= 9; n++) if (!used.has(n)) out.push(n);
  return out;
}
function relatedIndices(index) {
  const r = Math.floor(index / 9);
  const c = index % 9;
  const br = Math.floor(r / 3) * 3;
  const bc = Math.floor(c / 3) * 3;
  const set = /* @__PURE__ */ new Set();
  for (let i = 0; i < 9; i++) {
    set.add(r * 9 + i);
    set.add(i * 9 + c);
  }
  for (let dr = 0; dr < 3; dr++) for (let dc = 0; dc < 3; dc++) set.add((br + dr) * 9 + (bc + dc));
  return set;
}
const $$splitComponentImporter$1 = () => import("./play-cTNATooS.mjs");
const Route$1 = createFileRoute("/play")({
  validateSearch: (search) => ({
    d: DIFFICULTIES.includes(search.d) ? search.d : void 0,
    new: search.new ? 1 : void 0
  }),
  head: () => ({
    meta: [{
      title: "Solving — Prism Vault"
    }, {
      name: "description",
      content: "Solve a Sudoku puzzle in the Ember Vault."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const $$splitComponentImporter = () => import("./index-BT77zhQO.mjs");
const Route = createFileRoute("/")({
  head: () => ({
    meta: [{
      title: "Prism Vault — Sudoku"
    }, {
      name: "description",
      content: "Enter the vault. A premium, animation-rich Sudoku experience."
    }, {
      property: "og:title",
      content: "Prism Vault — Sudoku"
    }, {
      property: "og:description",
      content: "Enter the vault. A premium, animation-rich Sudoku experience."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const SettingsRoute = Route$2.update({
  id: "/settings",
  path: "/settings",
  getParentRoute: () => Route$3
});
const PlayRoute = Route$1.update({
  id: "/play",
  path: "/play",
  getParentRoute: () => Route$3
});
const IndexRoute = Route.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$3
});
const rootRouteChildren = {
  IndexRoute,
  PlayRoute,
  SettingsRoute
};
const routeTree = Route$3._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const queryClient = new QueryClient();
  const router2 = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  DIFFICULTIES as D,
  Route$1 as R,
  allConflicts as a,
  router as b,
  countRemaining as c,
  findHint as f,
  generatePuzzle as g,
  isComplete as i,
  relatedIndices as r
};
