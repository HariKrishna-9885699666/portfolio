const KEY = "prism-vault-game-v1";
const STATS_KEY = "prism-vault-stats-v1";
function loadGame() {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}
function saveGame(g) {
  if (typeof window === "undefined") return;
  if (!g) localStorage.removeItem(KEY);
  else localStorage.setItem(KEY, JSON.stringify(g));
}
function loadStats() {
  if (typeof window === "undefined") return { solved: 0, bestTimes: {}, streak: 0 };
  try {
    const raw = localStorage.getItem(STATS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
  }
  return { solved: 0, bestTimes: {}, streak: 0 };
}
function recordSolve(difficulty, seconds) {
  const stats = loadStats();
  stats.solved += 1;
  const prev = stats.bestTimes[difficulty];
  if (!prev || seconds < prev) stats.bestTimes[difficulty] = seconds;
  const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  if (stats.lastSolvedDate !== today) {
    const y = new Date(Date.now() - 864e5).toISOString().slice(0, 10);
    stats.streak = stats.lastSolvedDate === y ? stats.streak + 1 : 1;
    stats.lastSolvedDate = today;
  }
  localStorage.setItem(STATS_KEY, JSON.stringify(stats));
  return stats;
}
export {
  loadStats as a,
  loadGame as l,
  recordSolve as r,
  saveGame as s
};
