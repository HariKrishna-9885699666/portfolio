import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { d as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { R as Route$1, a as allConflicts, r as relatedIndices, i as isComplete, f as findHint, c as countRemaining, g as generatePuzzle } from "./router-Dl4GELfc.mjs";
import { l as loadGame, s as saveGame, r as recordSolve } from "./storage-BKErskxS.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
function newGame(difficulty) {
  const {
    puzzle,
    solution
  } = generatePuzzle(difficulty);
  return {
    puzzle,
    solution,
    board: puzzle.slice(),
    notes: new Array(81).fill(0),
    difficulty,
    elapsedSec: 0,
    mistakes: 0,
    hintsUsed: 0,
    history: [],
    startedAt: Date.now()
  };
}
function Play() {
  const search = Route$1.useSearch();
  const navigate = useNavigate();
  const [game, setGame] = reactExports.useState(null);
  const [selected, setSelected] = reactExports.useState(null);
  const [notesMode, setNotesMode] = reactExports.useState(false);
  const [elapsed, setElapsed] = reactExports.useState(0);
  const [paused, setPaused] = reactExports.useState(false);
  const [shake, setShake] = reactExports.useState(false);
  const [completed, setCompleted] = reactExports.useState(false);
  const startTimeRef = reactExports.useRef(Date.now());
  reactExports.useEffect(() => {
    const existing = loadGame();
    let g;
    if (search.new && search.d) {
      g = newGame(search.d);
    } else if (existing) {
      g = existing;
    } else {
      g = newGame(search.d ?? "medium");
    }
    setGame(g);
    setElapsed(g.elapsedSec);
    startTimeRef.current = Date.now() - g.elapsedSec * 1e3;
    if (search.new || search.d) {
      navigate({
        to: "/play",
        search: {},
        replace: true
      });
    }
  }, []);
  reactExports.useEffect(() => {
    if (!game || paused || completed) return;
    const id = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startTimeRef.current) / 1e3));
    }, 1e3);
    return () => clearInterval(id);
  }, [game, paused, completed]);
  reactExports.useEffect(() => {
    if (!game || completed) return;
    saveGame({
      ...game,
      elapsedSec: elapsed
    });
  }, [game, elapsed, completed]);
  const conflicts = reactExports.useMemo(() => game ? allConflicts(game.board) : /* @__PURE__ */ new Set(), [game]);
  const placeNumber = reactExports.useCallback((n) => {
    if (!game || selected === null || completed) return;
    if (game.puzzle[selected] !== 0) return;
    const history = [...game.history, {
      board: game.board.slice(),
      notes: game.notes.slice()
    }].slice(-50);
    const board = game.board.slice();
    const notes = game.notes.slice();
    if (notesMode && n !== 0) {
      notes[selected] = notes[selected] ^ 1 << n;
    } else {
      board[selected];
      board[selected] = n;
      notes[selected] = 0;
      if (n !== 0) {
        relatedIndices(selected).forEach((idx) => {
          if (notes[idx] & 1 << n) notes[idx] = notes[idx] ^ 1 << n;
        });
      }
      let mistakes = game.mistakes;
      if (n !== 0 && n !== game.solution[selected]) {
        mistakes += 1;
        setShake(true);
        setTimeout(() => setShake(false), 250);
      }
      const next = {
        ...game,
        board,
        notes,
        history,
        mistakes
      };
      setGame(next);
      if (isComplete(board, game.solution)) {
        setCompleted(true);
        recordSolve(game.difficulty, elapsed);
        saveGame(null);
      }
      return;
    }
    setGame({
      ...game,
      board,
      notes,
      history
    });
  }, [game, selected, notesMode, completed, elapsed]);
  const erase = reactExports.useCallback(() => {
    if (!game || selected === null) return;
    if (game.puzzle[selected] !== 0) return;
    const history = [...game.history, {
      board: game.board.slice(),
      notes: game.notes.slice()
    }].slice(-50);
    const board = game.board.slice();
    const notes = game.notes.slice();
    board[selected] = 0;
    notes[selected] = 0;
    setGame({
      ...game,
      board,
      notes,
      history
    });
  }, [game, selected]);
  const undo = reactExports.useCallback(() => {
    if (!game || game.history.length === 0) return;
    const last = game.history[game.history.length - 1];
    setGame({
      ...game,
      board: last.board.slice(),
      notes: last.notes.slice(),
      history: game.history.slice(0, -1)
    });
  }, [game]);
  const useHint = reactExports.useCallback(() => {
    if (!game) return;
    const hint = findHint(game.board, game.solution);
    if (!hint) return;
    setSelected(hint.index);
    const history = [...game.history, {
      board: game.board.slice(),
      notes: game.notes.slice()
    }].slice(-50);
    const board = game.board.slice();
    board[hint.index] = hint.value;
    const notes = game.notes.slice();
    notes[hint.index] = 0;
    const next = {
      ...game,
      board,
      notes,
      history,
      hintsUsed: game.hintsUsed + 1
    };
    setGame(next);
    if (isComplete(board, game.solution)) {
      setCompleted(true);
      recordSolve(game.difficulty, elapsed);
      saveGame(null);
    }
  }, [game, elapsed]);
  if (!game) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-muted-foreground", children: "Loading vault…" }) });
  }
  const selectedValue = selected !== null ? game.board[selected] : 0;
  const related = selected !== null ? relatedIndices(selected) : /* @__PURE__ */ new Set();
  const fmt = (s) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-background text-foreground", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto flex min-h-screen max-w-md flex-col px-5 pb-6 pt-10", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "mb-6 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", className: "flex flex-col", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] uppercase tracking-[0.2em] text-muted-foreground", children: "← Vault Chamber" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-serif text-lg capitalize text-foreground", children: game.difficulty })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-end", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] uppercase tracking-[0.2em] text-muted-foreground", children: "Duration" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium tabular-nums text-primary", children: fmt(elapsed) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setPaused((p) => !p), "aria-label": paused ? "Resume" : "Pause", className: "flex size-10 items-center justify-center rounded-full bg-card ring-1 ring-border transition-transform active:scale-95", children: paused ? /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 24 24", fill: "currentColor", className: "size-4 text-primary", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M8 5v14l11-7z" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", className: "size-4 text-muted-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M15.75 5.25v13.5m-7.5-13.5v13.5" }) }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `relative ${shake ? "animate-shake" : ""}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `aspect-square w-full rounded-2xl bg-card p-1.5 shadow-2xl ring-1 ring-border animate-vault-rise ${paused ? "blur-md pointer-events-none" : ""}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Board, { game, selected, setSelected, selectedValue, related, conflicts }) }),
        paused && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setPaused(false), className: "rounded-full bg-primary px-6 py-3 font-serif text-primary-foreground shadow-[0_0_30px_oklch(0.84_0.16_85/0.5)]", children: "Resume" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 grid grid-cols-4 gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ActionButton, { label: "Undo", onClick: undo, disabled: game.history.length === 0, children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", className: "size-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M9 15L3 9m0 0l6-6M3 9h12a6 6 0 010 12h-3" }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ActionButton, { label: "Erase", onClick: erase, children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", className: "size-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M3 21l8-8m0 0l8-8m-8 8l8 8M11 13L3 5" }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ActionButton, { label: notesMode ? "Notes On" : "Notes", onClick: () => setNotesMode((n) => !n), active: notesMode, children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", className: "size-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L6.832 19.82a4.5 4.5 0 0 1-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 0 1 1.13-1.897L16.863 4.487Zm0 0L19.5 7.125" }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ActionButton, { label: `Hint (${game.hintsUsed})`, onClick: useHint, children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", className: "size-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z" }) }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-auto pt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-5 gap-2", children: [
        [1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => {
          const remaining = countRemaining(game.board, n);
          const done = remaining <= 0;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => placeNumber(n), disabled: done && !notesMode, className: `relative flex h-14 flex-col items-center justify-center rounded-xl bg-card ring-1 ring-border transition-all active:scale-95 active:ring-primary/60 ${done ? "opacity-30" : ""}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-serif text-xl", children: n }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[8px] font-medium text-muted-foreground", children: Math.max(0, remaining) })
          ] }, n);
        }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: erase, className: "flex h-14 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-[0_0_20px_oklch(0.84_0.16_85/0.3)] transition-transform active:scale-95", "aria-label": "Clear cell", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", className: "size-5", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M6 18L18 6M6 6l12 12" }) }) })
      ] }) })
    ] }),
    completed && /* @__PURE__ */ jsxRuntimeExports.jsx(CompleteOverlay, { difficulty: game.difficulty, time: elapsed, mistakes: game.mistakes, hints: game.hintsUsed })
  ] });
}
function ActionButton({
  label,
  onClick,
  children,
  active,
  disabled
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick, disabled, className: "group flex flex-col items-center gap-1 disabled:opacity-40", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `flex size-12 items-center justify-center rounded-xl ring-1 transition-all group-active:translate-y-px ${active ? "bg-primary/15 text-primary ring-primary/50" : "bg-card text-muted-foreground ring-border"}`, children }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] font-medium uppercase tracking-tight ${active ? "text-primary" : "text-muted-foreground"}`, children: label })
  ] });
}
function Board({
  game,
  selected,
  setSelected,
  selectedValue,
  related,
  conflicts
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid h-full grid-cols-3 grid-rows-3 gap-1", children: Array.from({
    length: 9
  }, (_, blockIdx) => {
    const isDarkBlock = (Math.floor(blockIdx / 3) + blockIdx % 3) % 2 === 1;
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid grid-cols-3 grid-rows-3 gap-0.5 overflow-hidden rounded-lg ring-1 ring-border/50 ${isDarkBlock ? "bg-secondary/50" : "bg-secondary/25"}`, children: Array.from({
      length: 9
    }, (_2, cellIdx) => {
      const br = Math.floor(blockIdx / 3) * 3;
      const bc = blockIdx % 3 * 3;
      const r = br + Math.floor(cellIdx / 3);
      const c = bc + cellIdx % 3;
      const idx = r * 9 + c;
      return /* @__PURE__ */ jsxRuntimeExports.jsx(Cell, { idx, game, selected, onSelect: setSelected, selectedValue, isRelated: related.has(idx), isConflict: conflicts.has(idx) }, idx);
    }) }, blockIdx);
  }) });
}
function Cell({
  idx,
  game,
  selected,
  onSelect,
  selectedValue,
  isRelated,
  isConflict
}) {
  const value = game.board[idx];
  const isGiven = game.puzzle[idx] !== 0;
  const isSelected = selected === idx;
  const isMatch = value !== 0 && selectedValue !== 0 && value === selectedValue && !isSelected;
  const notes = game.notes[idx];
  const bg = isSelected ? "bg-primary text-primary-foreground ring-2 ring-primary/80" : isMatch ? "bg-primary/15" : isRelated ? "bg-primary/5" : "bg-background/60";
  const textColor = isSelected ? "text-primary-foreground" : isConflict ? "text-destructive" : isGiven ? "text-foreground/90" : "text-primary";
  return /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => onSelect(idx), className: `relative flex aspect-square items-center justify-center font-serif text-lg transition-colors ${bg}`, children: value !== 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `${textColor} ${!isGiven ? "animate-pop-in" : ""}`, children: value }) : notes ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid h-full w-full grid-cols-3 grid-rows-3 p-0.5 leading-none", children: Array.from({
    length: 9
  }, (_, i) => {
    const n = i + 1;
    const on = (notes & 1 << n) !== 0;
    return /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `flex items-center justify-center text-[8px] font-medium ${on ? "text-muted-foreground" : "text-transparent"}`, children: n }, n);
  }) }) : null });
}
function CompleteOverlay({
  difficulty,
  time,
  mistakes,
  hints
}) {
  const fmt = (s) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-background/85 backdrop-blur-md", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-6 max-w-sm rounded-3xl bg-card p-8 text-center ring-1 ring-primary/30 shadow-[0_0_60px_oklch(0.84_0.16_85/0.3)] animate-vault-rise", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto mb-4 flex size-16 items-center justify-center rounded-full bg-primary text-primary-foreground animate-ember-pulse", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", className: "size-7", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "m4.5 12.75 6 6 9-13.5" }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] uppercase tracking-[0.3em] text-primary", children: "Vault Unlocked" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "mt-2 font-serif text-3xl capitalize italic", children: [
      difficulty,
      " solved"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 grid grid-cols-3 gap-3 text-left", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Metric, { label: "Time", value: fmt(time) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Metric, { label: "Mistakes", value: mistakes.toString() }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Metric, { label: "Hints", value: hints.toString() })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex flex-col gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/play", search: {
        d: difficulty,
        new: 1
      }, reloadDocument: true, className: "rounded-xl bg-primary py-3 font-serif text-primary-foreground transition-transform active:scale-95", children: "Next puzzle" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: "rounded-xl bg-secondary py-3 font-serif text-foreground ring-1 ring-border transition-transform active:scale-95", children: "Return to vault" })
    ] })
  ] }) });
}
function Metric({
  label,
  value
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-lg bg-secondary/60 p-3 ring-1 ring-border", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[9px] uppercase tracking-[0.2em] text-muted-foreground", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 font-serif text-base tabular-nums", children: value })
  ] });
}
export {
  Play as component
};
